<?php
require_once 'cmb2/init.php';
function designr_register_metaboxes() {
	$prefix = 'designr_';
   global $designr;
	$designr_testimonials = new_cmb2_box( array(
		'id'            => $prefix . 'metabox',
		'title'         => esc_html( 'Testimonial Details', 'designr' ),
		'object_types'  => array( 'testimonials' ), // Post type
	) );

	$designr_testimonials->add_field( array(
		'name'    => esc_html( 'Name', 'designr' ),
		'desc'    => esc_html( '', 'designr' ),
		'id'      => $prefix . 'name',
		'type'    => 'text',
		'default' => 'John Doe',
	)	);
		$designr_testimonials->add_field( array(
		'name'    => esc_html( 'Job', 'designr' ),
		'desc'    => esc_html( '', 'designr' ),
		'id'      => $prefix . 'job',
		'type'    => 'text',
		'default' => 'WEB DESIGNER')	);
$masonry_pages = new_cmb2_box( array(
		'id'            => $prefix . 'masonries',
		'title'         => esc_html( 'Grid Details', 'designr' ),
		'object_types'  => array( 'page' ),
		'show_on' => array('key'=>'page-template','value'=>array('template-blog-masonry-4.php','template-blog-masonry-3.php','template-blog-masonry-2.php','template-blog-masonry-4-random.php','template-blog-masonry-4-random-2.php')),
		'context'      => 'normal', //  'normal', 'advanced', or 'side'
		'priority'     => 'high',  //  'high', 'core', 'default' or 'low'
		'show_names'   => true, // Show field names on the left
	) );
	$masonry_pages->add_field( array(
		'name'    => esc_html( 'Grid Width', 'designr' ),
		'desc'    => esc_html( 'Default: 1180px. For fullwidth grid enter: 100%', 'designr' ),
		'id'      => $prefix . 'pagewidth',
		'type'    => 'text_small',
		'default' => '1180px')	);
	$masonry_pages->add_field( array(
		'name'    => esc_html( 'Margin Left & Right', 'designr' ),
		'desc'    => esc_html( 'In pixels or percentages (15px or 5%)', 'designr' ),
		'id'      => $prefix . 'margin-right',
		'type'    => 'text_small',
		'default' => '20px')	);
	$masonry_pages->add_field( array(
		'name'    => esc_html( 'Margin Top & Bottom', 'designr' ),
		'desc'    => esc_html( 'In pixels or percentages (15px or 5%)', 'designr' ),
		'id'      => $prefix . 'margin-bottom',
		'type'    => 'text_small',
		'default' => '20px')	);
	$masonry_pages->add_field( array(
	'name'    => 'Show Titles?',
	'id'      => $prefix.'show_titles',
	'type'    => 'radio_inline',
	'options' => array(
		'show' => __( 'Show', 'designr' ),
		'hide'   => __( 'Hide', 'designr' ),
	),
	'default' => 'show',
) );
	$masonry_pages->add_field( array(
	'name'    => 'Show Excerpts?',
	'id'      => $prefix.'show_excerpts',
	'type'    => 'radio_inline',
	'options' => array(
		'show' => __( 'Show', 'designr' ),
		'hide'   => __( 'Hide', 'designr' ),
	),
	'default' => 'show',
) );
	$masonry_pages->add_field( array(
		'name'    => esc_html( 'Excerpt Length', 'designr' ),
		'desc'    => esc_html( 'How many words in excerpt? Default 20', 'designr' ),
		'id'      => $prefix . 'excerpt_length',
		'type'    => 'text_small',
		'default' => '20')	);
	$masonry_pages->add_field( array(
	'name'    => 'Show Featured Images?',
	'id'      => $prefix.'show_featured_images',
	'type'    => 'radio_inline',
	'options' => array(
		'show' => __( 'Show', 'designr' ),
		'hide'   => __( 'Hide', 'designr' ),
	),
	'default' => 'show',
) );
	$masonry_pages->add_field( array(
	'name'    => 'Apply card design to sticky posts?',
	'id'      => $prefix.'stickies',
	'type'    => 'radio_inline',
	'options' => array(
		'show' => __( 'Apply', 'designr' ),
		'hide'   => __( 'Nope', 'designr' ),
	),
	'default' => 'hide',
) );
}

add_action( 'cmb2_admin_init', 'designr_register_metaboxes' );