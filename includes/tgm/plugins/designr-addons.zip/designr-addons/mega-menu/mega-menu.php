<?php
// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! class_exists( 'Designr_Modules_MegaMenuModule', false ) ) :

	class Designr_Modules_MegaMenuModule {

		/**
		 * Execute module.
		 */
		public static function execute() {
			require 'class-edit-menu-walker.php';
			require 'class-mega-menu-admin.php';
			require 'class-mega-menu-front.php';
			require 'class-frontend-menu.php';			

			Designr_Modules_MegaMenu_Admin::execute();
			Designr_Modules_MegaMenu_Front::execute();
		}
	}

	Designr_Modules_MegaMenuModule::execute();

endif;
