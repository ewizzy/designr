<?php
namespace HelloWorld;
use HelloWorld\Widgets\Designr_Testimonials;
use HelloWorld\Widgets\Designr_Portfolio;
use HelloWorld\Widgets\Designr_Progress;
use HelloWorld\Widgets\Designr_CF7;
use HelloWorld\Widgets\Designr_Pricing_Tables;
use HelloWorld\Widgets\Designr_Woo_Products_Grid;
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Main Plugin Class
 *
 * Register new elementor widget.
 *
 * @since 1.0.0
 */
class Plugin {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	 
	public function __construct() {
		
		$this->add_actions();
	}

	/**
	 * Add Actions
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function add_actions() {
		
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		if(class_exists('WooCommerce')){ 
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments) {
    ob_start();
    $count= WC()->cart->cart_contents_count;
    ?><a class="cart-contents"href="<?php echo WC()->cart->get_cart_url(); ?>"title="<?php _e( 'View your shopping cart' ); ?>">
	<i class="fa fa-shopping-cart"></i>
	<?php
    if( $count> 0 ) {
        ?>
        <span class="cart-contents-count"><?php echo sprintf ( _n( '%d item', '%d items', WC()->cart->get_cart_contents_count() ), WC()->cart->get_cart_contents_count() ); ?></span>
        <?php           
    }
	else { ?>
		<span class="cart-contents-count">0 Items</span>
		<?php
	}
        ?></a><?php
    $fragments['a.cart-contents'] = ob_get_clean();
    
    return$fragments;
});
		}
        if ( is_plugin_active( 'elementor/elementor.php' ) ) {
		update_option( 'elementor_disable_color_schemes', 'yes' );
update_option( 'elementor_disable_typography_schemes', 'yes' );	
		add_action( 'elementor/init', array( $this, 'add_elementor_category' ) );
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'on_widgets_registered' ] );
		add_action( 'elementor/frontend/after_register_scripts', function() {
			wp_register_script( 'jquery-filterizr', plugins_url( '/assets/js/jquery.filterizr.js', ELEMENTOR_designr__FILE__ ), [ 'jquery' ], false, true );
		} );
		}
		add_action('init', function(){
			    if ( class_exists('ReduxFrameworkPlugin') ) {
        remove_filter( 'plugin_row_meta', array( ReduxFrameworkPlugin::get_instance(), 'plugin_metalinks'), null, 2 );
        remove_action('admin_notices', array( ReduxFrameworkPlugin::get_instance(), 'admin_notices' ) );    
    }
		});
function designr_themeurl(){
	return get_stylesheet_directory_uri();
}
add_shortcode( 'templateurl', 'designr_themeurl' );
add_filter( 'body_class', function( $classes ) {
		global $designr;
		if($designr['preload-switch']==1){
    return array_merge( $classes, array( 'is-loading' ) );
		}
		else { return $classes; }
} );
add_action( 'wp_footer', function(){ 
global $designr;
if(!isset($designr['sticky-start']['height'])){ $sticks= 999999;}
else {
	$sticks = $designr['sticky-start']['height'];
}
echo '
<script type="text/javascript">
jQuery(document).ready(function(){
	jQuery("#mainNav").data("bs.affix").options.offset = '.$sticks.';
});
</script>';
},215 );
/*
function designr_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'designr_mime_types', 1, 1);*/

add_filter('widget_text','do_shortcode');

		include 'all.php';
	}
    public function add_elementor_category()
    {
        \Elementor\Plugin::instance()->elements_manager->add_category( 'designr-elements', array(
            'title' => __( 'Designr Addons', 'designr' ),
        ), 1 );
	}
	/**
	 * On Widgets Registered
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function on_widgets_registered() {
		$this->includes();
		$this->register_widget();
	}

	/**
	 * Includes
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function includes() {
		require __DIR__ . '/widgets/testimonials.php';
		require __DIR__ . '/widgets/portfolio.php';
		require __DIR__ . '/widgets/progress2.php';
		require __DIR__ . '/widgets/cf7.php';
		require __DIR__ . '/widgets/woo-products-grid.php';
		require __DIR__ . '/widgets/pricing-tables.php';
	}

	/**
	 * Register Widget
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 */
	private function register_widget() {
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Designr_Testimonials() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Designr_Portfolio() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Designr_Progress() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Designr_CF7() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Designr_Woo_Products_Grid() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Designr_Pricing_Tables() );
	}
}
new Plugin();