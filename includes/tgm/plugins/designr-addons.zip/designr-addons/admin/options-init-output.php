<?php

    /**
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "designr";
	$styleurl = get_stylesheet_directory_uri();
    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        'opt_name' => 'designr',
        'use_cdn' => false,
        'display_name' => 'Theme Options',
        'display_version' => FALSE,
        'page_slug' => 'designr',
        'page_title' => 'Theme Options',
        'update_notice' => FALSE,
        'menu_type' => 'menu',
        'menu_title' => 'Theme Options',
        'allow_sub_menu' => TRUE,
        'page_parent' => 'themes.php',
		'disable_tracking' => true,
        'customizer' => TRUE,
        'default_mark' => '',
        'hints' => array(
            'icon_position' => 'right',
            'icon_size' => 'normal',
            'tip_style' => array(
                'color' => 'light',
            ),
            'tip_position' => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect' => array(
                'show' => array(
                    'duration' => '500',
                    'event' => 'mouseover',
                ),
                'hide' => array(
                    'duration' => '500',
                    'event' => 'mouseleave unfocus',
                ),
            ),
        ),
        'settings_api' => TRUE,
        'cdn_check_time' => '1440',
        'output' => TRUE,
		'output_tag' => TRUE,
        'page_permissions' => 'manage_options',
        'save_defaults' => TRUE,
        'show_import_export' => TRUE,
        'transient_time' => '3600',
        'network_sites' => TRUE,
		'dev_mode' => false,
		'disable_tracking' => true,
		'footer_credit' => '',
		'show_options_object' => FALSE,
		'customizer' => TRUE
    );
Redux::setArgs( $opt_name, $args );
 
    /*
     *
     * ---> START SECTIONS
     *
     */
    Redux::setSection( $opt_name, array(
        'title' => __( 'Header Creator', 'redux-framework-demo' ),
        'id'    => 'headercreator',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-tasks',
		 'fields' => array(
		 array(
    'id'       => 'headerID',
    'type'     => 'image_select',
	'class' => 'bigimgsba',
			'default' => 1,
    'title'    => __('Please choose header layout', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'options'  => array(
        '1'      => array(
            'alt'   => 'Header 1 (Regular header, just menu on right. No icons/buttons)', 
            'img'   => $styleurl.'/includes/headers/images/header1.png'
        ),
        '2'      => array(
             'alt'   => 'Header 2 (Centered menu, icons&button on right)', 
            'img'   => $styleurl.'/includes/headers/images/header2.png'
        )
    )
        ))
    ) );
	    Redux::setSection( $opt_name, array(
        'title'      => __( 'Top Bar', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'opt-text-subsection-2',
        'subsection' => true,
        'fields'     => array(
				array(
    'id'       => 'topbar-switch',
    'type'     => 'switch', 
    'title'    => __('Use top bar?', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => true,
),
array(
    'id'               => 'topbar-content',
    'type'             => 'editor',
    'title'            => __('Top bar content', 'redux-framework-demo'), 
    'subtitle'         => __('Or use top bar content presets under this field', 'redux-framework-demo'),
    'default'          => 'Powered by Redux.',
	'required' => array('topbar-switch','equals','1'),
    'args'   => array(
        'textarea_rows'    => 2
    )
        ),
		array(
    'id'       => 'opt-presets2',
    'type'     => 'image_select', 
    'presets'  => true,
    'title'    => __('Top Bar Content Presets', 'redux-framework-demo'),
    'subtitle' => __('Easily import one of premade top bar contents', 'redux-framework-demo'),
    'default'  => 1,
	'required' => array('topbar-switch','equals','1'),
'desc'     => __('<i>* This will import only top bar content, nothing else</i>', 'redux-framework-demo'),
    'options'  => array(
        // Array of preset options
        '1'      => array(
            'alt'   => 'Skype and phone number on right side', 
			'title' => 'Skype and phone number on right side',
            'img'   => $styleurl.'/includes/headers/images/top-bar/preset1.png', 
            'presets'   => array(
                'topbar-content'     => '<a href="skype:example" style="margin-right:40px;color:#7F7E8C"><i class="fa"></i>designrskype</a><a href="tel:1-355-4902" style="color:#7F7E8C"><i class="fa"></i>1-355-4902</a>'
            )
        ),
        // JSON string of preset options
         '2'      => array(
            'alt'   => 'Skype and phone number on right side', 
            'img'   => $styleurl.'/includes/headers/images/top-bar/preset1.png', 
            'presets'   => array(
                'topbar-content'     => '<a href="skype:example" style="margin-right:40px"><i class="fa"></i>designrskype</a><a href="tel:1-355-4902"><i class="fa"></i>1-355-4902</a>'
            )
        )
    ),
),
		array(
    'id'       => 'topbar-bg',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => 'div.top-bar'),
    'title'    => __('Top bar background color', 'redux-framework-demo'), 
    'subtitle' => __('You can set opacity too', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#3b3843',
        'alpha'     => 1
    ),
	'required' => array('topbar-switch','equals','1')
),
array(
    'id'             => 'topbar-spacing',
    'type'           => 'spacing',
    'output'         => array('div.top-bar'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Top bar padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
	'required' => array('topbar-switch','equals','1')
),
		            array(
    'id'          => 'topbar-typ',
    'type'        => 'typography', 
    'title'       => __('Top bar typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => false,
	'color' => true,
    'output'      => array('div.top-bar *'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '14px', 
        'line-height' => '40px',
		'color' => '#fff'
    ),
	'required' => array('topbar-switch','equals','1')
        )
    ) ));
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Sticky Header', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'sticky-menu',
        'subsection' => true,
        'fields'     => array(
						array(
    'id'       => 'sticky-switch',
    'type'     => 'switch', 
    'title'    => __('Use sticky header?', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => true,
),
		array(
    'id'       => 'sticky-bg',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => 'nav.navbar-fixed-top.affix, nav.navbar-fixed-top.affix-bottom'),
    'title'    => __('Sticky header background color', 'redux-framework-demo'), 
    'subtitle' => __('You can set opacity too', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#3B3843',
        'alpha'     => 1
    ),
	'required' => array('sticky-switch','equals','1')
),
array(
    'id'       => 'sticky-start',
    'type'     => 'dimensions',
    'title'    => __('When to show sticky header?'),
    'subtitle' => __('How many pixels users needs to scroll before sticky header appears', 'redux-framework-demo'),
    'desc'     => __('', 'redux-framework-demo'),
	'width' => false,
	'units' => false,
    'default'  => array(
        'Height'  => '90'
    ),
	'required' => array('sticky-switch','equals','1')
),
array(
    'id'             => 'sticky-spacing',
    'type'           => 'spacing',
    'output'         => array('nav#mainNav.affix, nav.navbar-fixed-top.affix-bottom'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Sticky Header padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
	'required' => array('sticky-switch','equals','1')
),
        )
    ) );
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Menu Settings', 'redux-framework-demo' ),
        'desc'       => __('Main menu, submenu, mega menu and responsive menu settings.'),
        'id'         => 'opt-text-subsection-menus',
        'subsection' => true,
        'fields'     => array(
            				            array(
    'id'          => 'topmenu',
    'type'        => 'typography', 
    'title'       => __('Main Menu', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
    'output'      => array('ul#TopMenu > li > a'),
    'units'       =>'px',
	'text-align' => false,
	'letter-spacing' => true,
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '22px',
		'color' => '#FFFFFF'
    ),
        ),
		            				            array(
    'id'          => 'topmenudropdown',
    'type'        => 'typography', 
    'title'       => __('Dropdown Menu List & Mega Menu List', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'text-align' => false,
    'output'      => array('ul.sub-nav li a:not(.not-clickable-item)'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
	'letter-spacing' => true,
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '22px',
		'color' => '#FFFFFF'
    ),
        ),
	array(
    'id'          => 'topmenudropdown2',
    'type'        => 'typography', 
    'title'       => __('Mega Menu Item Without Link', 'redux-framework-demo'),
	'desc' => __('If you choosed "Remove Link" while making menu then you can style it here'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'text-align' => false,
    'output'      => array('ul.sub-nav li a.not-clickable-item'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
	'letter-spacing' => true,
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '22px',
		'color' => '#FFFFFF'
    ),
        ),
			array(
    'id'          => 'topmenudropdown3',
    'type'        => 'typography', 
    'title'       => __('Mega Menu Description Field', 'redux-framework-demo'),
	'desc' => __('If you used "Description" field while making menu then you can style it here'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'text-align' => false,
    'output'      => array('ul span.subtitle-text'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
	'letter-spacing' => true,
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '22px',
		'color' => '#FFFFFF'
    ),
        ),
		array(
    'id'       => 'mmenubg',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => 'ul.mainmenu > li > ul.sub-nav, div.designr-mega-menu-wrap','border-bottom-color' => 'div.designr-mega-menu-wrap:before'),
    'title'    => __('Sub Menu & Mega Menu Background', 'redux-framework-demo'), 
    'subtitle' => __('You can set opacity too', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#FFFFFF',
        'alpha'     => 0
    )
),
		array(
    'id'       => 'mmenubgi',
    'type'     => 'color_rgba',
	'output'    => array('color' => '.designr-mega-menu-wrap ul li a i'),
    'title'    => __('Mega Menu Icon color', 'redux-framework-demo'), 
    'subtitle' => __('If you use font icon in menu (needs to be i tag)', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#FFFFFF',
        'alpha'     => 0
    )
),
	         array(
    'id'             => 'menumain-spacing',
    'type'           => 'spacing',
    'output'         => array('ul.mainmenu > li'),
    'mode'           => 'margin',
    'units'          => 'px',
	'top' => false,
	'left' => false,
	'bottom' => false,
    'units_extended' => 'false',
    'title'          => __('Menu Margin Right', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'margin-right'   => '15px'
    )
    ),
				 array(         
    'id'      => 'menu-borderradius',
    'type'    => 'box_shadow',
    'title'   => __('Sub Menu & Mega Menu Border Radius', 'redux-framework-demo'),
    'units'   => array( 'px', 'em', 'rem' ),
    'output'  => ( 'ul.mainmenu > li > ul.sub-nav, div.designr-mega-menu-wrap' ),
    'opacity' => true,
    'rgba'    => true,
	'preview' => false,
    'default' => array (
        'horizontal'   => '5px', 
    ),
),
array(
    'id'             => 'mmenupad',
    'type'           => 'spacing',
    'output'         => array('ul.mainmenu > li > ul.sub-nav, div.designr-mega-menu-wrap'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Sub Menu & Mega Menu Padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '10px', 
        'padding-right'   => '10px', 
        'padding-bottom'  => '10px', 
        'padding-left'    => '10px',
        'units'          => 'px', 
    )
),
array(
    'id'             => 'mmenupad2',
    'type'           => 'spacing',
    'output'         => array('ul.mainmenu > li > ul.sub-nav, div.designr-mega-menu-wrap'),
    'mode'           => 'margin',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Sub Menu & Mega Menu Margin', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'margin-top'     => '10px', 
        'margin-right'   => '0px', 
        'margin-bottom'  => '0px', 
        'margin-left'    => '0px',
        'units'          => 'px', 
    )
),
array(
    'id'             => 'rmenupad',
    'type'           => 'spacing',
    'output'         => array('button.navbar-toggle'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Responsive Menu Padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('Visible on mobiles and tablets', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '10px', 
        'padding-right'   => '10px', 
        'padding-bottom'  => '10px', 
        'padding-left'    => '10px',
        'units'          => 'px', 
    )
),
			array(
    'id'          => 'rmenud',
    'type'        => 'typography', 
    'title'       => __('Responsive Menu Typography', 'redux-framework-demo'),
	'desc' => __('Visible on mobiles and tablets'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'text-align' => false,
    'output'      => array('button.navbar-toggle, div#bs-example-navbar-collapse-2 li a'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
	'letter-spacing' => true,
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '22px',
		'color' => '#FFFFFF'
    ),
        ),
				array(
    'id'       => 'rmenubgc',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => 'button.navbar-toggle'),
    'title'    => __('Responsive Menu Background', 'redux-framework-demo'), 
    'subtitle' => __('You can set it to transparent too.', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#FFFFFF',
        'alpha'     => 0
    )
),
        )
    ) );
	Redux::setSection( $opt_name, array(
        'title'      => __( 'Other Settings', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'opt-text-subsection-menus4',
        'subsection' => true,
        'fields'     => array(
		array(
    'id'       => 'header-margin',
    'type'     => 'dimensions',
	'output'    => array('margin-top' => 'header'),
    'title'    => __('Header Height'),
    'subtitle' => __('Enter 0 to have header transparent, otherwise enter 50 or bigger, depends on how big header you want', 'redux-framework-demo'),
    'desc'     => __('(For example: 70 means push content 70 pixels down)', 'redux-framework-demo'),
	'width' => false,
	'units' => "px",
    'default'  => "0"
),
				array(
    'id'       => 'h-bg',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => 'header'),
    'title'    => __('Header Background Color, if background color do not appear please enter <b>"Header Height"</b> value above', 'redux-framework-demo'), 
    'subtitle' => __('You can set opacity too', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#FFF',
        'alpha'     => 0
    )
),
		array(
    'id'       => 'logo1',
    'type'     => 'media', 
    'url'      => true,
    'title'    => __('Main Logo', 'redux-framework-demo'),
    'desc'     => __('', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => array(
        'url'=> $styleurl.'/img/logo.png'
		)
    ),
			array(
    'id'       => 'logo2',
    'type'     => 'media', 
    'url'      => true,
    'title'    => __('Sticky Header Logo', 'redux-framework-demo'),
    'desc'     => __('If you use <b>"Sticky Header"</b> feature please upload logo, it can be same of course.', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => array(
        'url'=> $styleurl.'/img/logo2.png'
		)
    ),
		array(
    'id'       => 'search-switch',
    'type'     => 'button_set', 
    'title'    => __('Add More Elements To Header?', 'redux-framework-demo'),
    'subtitle' => __('You can add modal menu or/and modal search box', 'redux-framework-demo'),
    'default'  => '1',
	'options' => array(
        '1' => 'Add Menu', 
        '2' => 'Add Search', 
        '3' => 'None',
		'4' => 'Add Both'
     ), 
),
		array(
    'id'       => 'menu-style',
    'type'     => 'button_set', 
    'title'    => __('Choose Menu Icon Wrap Style', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '1',
	'required' => array(array('search-switch','!=','2'),array('search-switch','!=','3')),
	'options' => array(
        '1' => 'Just Icon', 
        '2' => 'Icon In Circle',
		'3' => 'Icon In Cube'
     ), 
),
array(
    'id'       => 'menu-icon-color',
    'type'     => 'color',
	'output'    => array('background-color' => '.designr-modal-menu > span, .designr-modal-menu i, .designr-modal-menu i::before, .designr-modal-menu i::after'),
    'title'    => __('Menu Icon Color', 'redux-framework-demo'), 
	'required' => array(array('search-switch','!=','2'),array('search-switch','!=','3')),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#6390FF',
	'important' => true,
    'validate' => 'color',
	'transparent' => false
),
		 array(
    'id'       => 'menuiconstyle',
    'type'     => 'image_select',
			'default' => 1,
    'title'    => __('Choose Icon Design', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'options'  => array(
        '1'      => array(
            'img'   => $styleurl.'/includes/headers/images/menuicon1.png'
        ),
        '2'      => array(
            'img'   => $styleurl.'/includes/headers/images/menuicon2.png'
        ),
		'3'      => array(
            'img'   => $styleurl.'/includes/headers/images/menuicon3.png'
        )
    )
        ),
array(
    'id'       => 'search-icon-color',
    'type'     => 'color',
	'output'    => array('color' => 'div.designr-search i'),
    'title'    => __('Search Icon Color', 'redux-framework-demo'), 
	'required' => array(array('search-switch','!=','1'),array('search-switch','!=','3')),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#6390FF',
	'important' => true,
    'validate' => 'color',
	'transparent' => false
),
array(
    'id'       => 'search-icon-color2',
    'type'     => 'color',
	'output'    => array('color' => 'div.designr-search i:hover'),
    'title'    => __('Search Icon Color On Hover', 'redux-framework-demo'), 
	'required' => array(array('search-switch','!=','1'),array('search-switch','!=','3')),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#6390FF',
	'important' => true,
    'validate' => 'color',
	'transparent' => false
),
		array(
    'id'       => 'overlay-bg',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => 'div.overlay, div.overlay2'),
    'title'    => __('Modal Background Color', 'redux-framework-demo'), 
    'subtitle' => __('You can set opacity too', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#111',
        'alpha'     => 0.8
    ),
	'required' => array('search-switch','!=','3'),
),
		            array(
    'id'          => 'modal-typ',
    'type'        => 'typography', 
    'title'       => __('Modal Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => false,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('div.overlay *, div.overlay2 *'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '18px', 
        'line-height' => '40px',
		'color' => '#fff'
    ),
	'required' => array('search-switch','!=','3')
        ),
		array(
    'id'       => 'hbutton-switch',
    'type'     => 'button_set', 
    'title'    => __('Add Header Button?', 'redux-framework-demo'),
    'subtitle' => __('Works on some headers only.', 'redux-framework-demo'),
    'default'  => '2',
	'options' => array(
        '1' => 'Yes', 
        '2' => 'No'
     ), 
),
		array(
    'id'   => 'info_wppages24',
    'type' => 'info',
	'required' => array('hbutton-switch','=','1'),
    'desc' => __('Button styling is in <b><i>General Settings -> Default Button</i></b>', 'redux-framework-demo')
),
array(
    'id'       => 'hbuttontxt',
    'type'     => 'text',
	'required' => array('hbutton-switch','equals','1'),
    'title'    => __('Button Text', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => 'BUY NOW'
),
array(
    'id'       => 'hbuttonlink',
    'type'     => 'text',
	'required' => array('hbutton-switch','equals','1'),
    'title'    => __('Button Link', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => 'http://yoursite.com'
),
array(
    'id'             => 'header-spacing',
    'type'           => 'spacing',
    'output'         => array('nav#mainNav'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Header padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    )
),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title' => __( 'General Settings', 'redux-framework-demo' ),
        'id'    => 'basic',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-wrench',
		 'fields' => array(
		array(
    'id'       => 'master1',
    'type'     => 'color',
	'output'    => array('background-color' => '.bluetags a:hover, .scheme1bg, figure.effect-zoomin p, ul.sub-menu, nav.navbar.navbar-default.navbar-custom.navbar-fixed-top.affix, nav.navbar-fixed-top.affix-bottom, .scheme1-btn', 'color' => 'div.posts-nav a:hover, ol a, span.current, section.page-content p a, p a, ul.page-numbers li a:hover, .blogpost h2 a:hover, div.dateinfo a, .bluetags a, .colorscheme1', 'border-color' => '.bluetags a, .scheme1-bordercolor:after'),
    'title'    => __('Master Color', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#3b3843',
    'validate' => 'color',
	'transparent' => false
),
		array(
    'id'       => 'master2',
    'type'     => 'color',
	'output'    => array('background-color' => '.scheme2-btn, .scheme2bg', 'color' => '.colorscheme2', 'border-color' => '.scheme2-bordercolor:after'),
    'title'    => __('Master Color 2', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#715e6b',
    'validate' => 'color',
	'transparent' => false
),
		array(
    'id'       => 'master3',
    'type'     => 'color',
	'output'    => array('background-color' => 'div.image-grid figure, .scheme3bg, .scheme3-btn, div.filtr-item a i:hover','color'=> 'section.page-content a:hover, ul#TopMenu li a:hover, div.filtr-item a i, .top-bar i.fa, .colorscheme3, footer ul a:hover, footer ol a:hover', 'background'=>'::selection, *::-moz-selection, img::selection, img::-moz-selection','border-color' => '.scheme3-bordercolor:after, hr'),
    'title'    => __('Master Color 3', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#f0b39d',
	'important' => true,
    'validate' => 'color',
	'transparent' => false
),
			array(
    'id'             => 'general-spacing',
    'type'           => 'spacing',
    'output'         => array('section.elementor-element'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Section padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('This padding affects all sections made with Elementor.', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '100px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '100px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
),	
        )
    ) );
Redux::setSection( $opt_name, array(
        'title'      => __( 'Pages Settings', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'wp-pages-settings',
        'subsection' => true,
        'fields'     => array(
		array(
    'id'   => 'info_wppages',
    'type' => 'info',
    'desc' => __('Those settings are for all pages which are not created on frontend with Elementor. Some of pages are: category, single post, page, author, 404, blog....', 'redux-framework-demo')
),
		array(
    'id'             => 'pages-heading-spacing',
    'type'           => 'spacing',
    'output'         => array('section.defpages'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Heading Area padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
),
		            array(
    'id'          => 'titltag',
    'type'        => 'typography', 
    'title'       => __('Heading Area Title Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('section.defpages h1.designr-h1'),
    'units'       =>'px',
    'subtitle'    => __('Its page title', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '32px', 
        'line-height' => '42px',
		'color' => '#FFFFFF',
		'letter-spacing' => '0.5px'
    ),
        ),
	array(
    'id'             => 'header-h1-spacing',
    'type'           => 'spacing',
    'output'         => array('section.defpages h1.designr-h1'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Heading Area Title Padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
),
		array(
    'id'   => 'info_wppages2',
    'type' => 'info',
    'desc' => __('Background settings under this notice are valid for default WordPress pages: category, single post, author, 404, search, tag, archive. For pages you create, you have background settings under editor.', 'redux-framework-demo')
),
array(         
    'id'       => 'heading-area-background',
    'type'     => 'background',
    'title'    => __('Heading Area Background', 'redux-framework-demo'),
	'output'      => array('section.defpages'),
    'subtitle' => __('', 'redux-framework-demo'),
    'desc'     => __('', 'redux-framework-demo'),
    'default'  => array(
        'background-color' => '#9048FB',
    )
     ) 
		)));
Redux::setSection( $opt_name, array(
        'title'      => __( 'Blog Settings', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'wp-blog-settings',
        'subsection' => true,
        'fields'     => array(
			 array(         
    'id'      => 'blog-borderradius',
    'type'    => 'box_shadow',
    'title'   => __('Border Radius On Blog Images', 'redux-framework-demo'),
    'units'   => array( 'px', 'em', 'rem' ),
    'output'  => ( 'img.wp-post-image, .blogpost a img' ),
    'opacity' => true,
    'rgba'    => true,
	'preview' => false,
    'default' => array (
        'horizontal'   => '5px', 
    ),
),
		            array(
    'id'          => 'blogdes',
    'type'        => 'typography', 
    'title'       => __('Blog "Posted On" Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('div.posted, div.dateinfo, div.post-tags, .bluetags'),
    'units'       =>'px',
    'subtitle'    => __('Available on some blog layouts + single post', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '14px', 
        'line-height' => '35px',
		'color' => '#6b7c93',
		'letter-spacing' => '1.5px'
    ),
        ),
				            array(
    'id'          => 'bnav',
    'type'        => 'typography', 
    'title'       => __('Blog Navigation Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('div.site-pagination, div.site-pagination ul li, div.site-pagination ul li a'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '17px', 
		'font-weight' => '700',
        'line-height' => '32px',
		'color' => '#2F0000',
		'letter-spacing' => '0.5px'
    ),
        ),
				array(
    'id'       => 'relatedposts-switch',
    'type'     => 'button_set', 
    'title'    => __('Show related posts on single post?', 'redux-framework-demo'),
    'subtitle' => __('Related posts are related by having atleast one same tag.', 'redux-framework-demo'),
    'default'  => '1',
	'options' => array(
        '1' => 'Show', 
        '2' => 'Hide'
     ), 
),
				array(
    'id'       => 'tagssh-switch',
    'type'     => 'button_set', 
    'title'    => __('Show tags on single post?', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '1',
	'options' => array(
        '1' => 'Show', 
        '2' => 'Hide'
     ), 
),

		)));		
Redux::setSection( $opt_name, array(
        'title'      => __( 'Sidebar Settings', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'wp-sidebar-settings',
        'subsection' => true,
        'fields'     => array(
         array(         
    'id'       => 'sidbg',
    'type'     => 'background',
    'title'    => __('Sidebar Background', 'redux-framework-demo'),
	'output'      => array('div.page-sidebar'),
    'subtitle' => __('', 'redux-framework-demo'),
    'desc'     => __('', 'redux-framework-demo'),
    'default'  => array(
        'background-color' => '#fff',
    )
     ), 
	 array(         
    'id'      => 'sid-borderradius',
    'type'    => 'box_shadow',
    'title'   => __('Border Radius', 'redux-framework-demo'),
    'units'   => array( 'px', 'em', 'rem' ),
    'output'  => ( 'div.page-sidebar' ),
    'opacity' => true,
    'rgba'    => true,
	'preview' => false,
    'default' => array (
        'horizontal'   => '5px', 
    ),
),
    	array(
    'id'             => 'sid-spacing',
    'type'           => 'spacing',
    'output'         => array('div.page-sidebar'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Sidebar Inner Padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '20px', 
        'padding-right'   => '35px', 
        'padding-bottom'  => '20px', 
        'padding-left'    => '35px',
        'units'          => 'px', 
    ),
),
array( 
    'id'       => 'sidebar-border',
    'type'     => 'border',
    'title'    => __('Sidebar Border Option', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'output'   => array('div.page-sidebar'),
    'desc'     => __('', 'redux-framework-demo'),
    'default'  => array(
        'border-color'  => '#fbfbfb', 
        'border-style'  => 'solid', 
        'border-top'    => '1px', 
        'border-right'  => '1px', 
        'border-bottom' => '1px', 
        'border-left'   => '1px'
    )
),
array(
    'id'       => 'card-sid-switch',
    'type'     => 'button_set', 
    'title'    => __('Apply Card design to sidebar?', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '1',
	'options' => array(
        '1' => 'Yes', 
        '2' => 'No'
     ), 
),

				            array(
    'id'          => 'widget-navs',
    'type'        => 'typography', 
    'title'       => __('Widget Title Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('div.page-sidebar aside .widget-title'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '18px', 
		'font-weight' => '400',
        'line-height' => '42px',
		'color' => '#2F0000',
		'letter-spacing' => '0.5px'
    ),
        ),
array( 
    'id'       => 'wtborder',
    'type'     => 'border',
    'title'    => __('Widget Title Border', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'all' => false,
    'output'   => array('div.page-sidebar aside .widget-title'),
    'desc'     => __('', 'redux-framework-demo'),
    'default'  => array(
        'border-color'  => '#6b7c93', 
        'border-style'  => 'solid', 
        'border-top'    => '0px', 
        'border-right'  => '0px', 
        'border-bottom' => '2px', 
        'border-left'   => '0px',
    )
),

) 
));
Redux::setSection( $opt_name, array(
        'title'      => __( 'Default Button', 'redux-framework-demo' ),
        'desc'       => __('Default button is used in header if you choosed header with button. Also its used on submit form button and all default WP pages. You can use it anywhere by adding class <b>btn-default</b> to anchor'),
        'id'         => 'def-btn',
        'subsection' => true,
        'fields'     => array(
		array( 
    'id'       => 'buttonborder',
    'type'     => 'border',
    'title'    => __('Button Border', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'all' => false,
    'output'   => array('.btn-default'),
    'desc'     => __('', 'redux-framework-demo'),
    'default'  => array(
        'border-color'  => '#6b7c93', 
        'border-style'  => 'solid', 
        'border-top'    => '1px', 
        'border-right'  => '1px', 
        'border-bottom' => '1px', 
        'border-left'   => '1px',
    )
),
		array( 
    'id'       => 'buttonborders',
    'type'     => 'border',
    'title'    => __('Button Border On Hover', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'all' => false,
    'output'   => array('.btn-default:hover'),
    'desc'     => __('', 'redux-framework-demo'),
    'default'  => array(
        'border-color'  => '#333333', 
        'border-style'  => 'solid', 
        'border-top'    => '1px', 
        'border-right'  => '1px', 
        'border-bottom' => '1px', 
        'border-left'   => '1px',
    )
),
		array(
    'id'       => 'btncolor4',
    'type'     => 'color',
	'output'    => array('color' => '.btn-default:hover'),
    'title'    => __('Button Text Color On Hover', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#333333',
	'important' => true,
    'validate' => 'color',
	'transparent' => false
),
		    	array(
    'id'             => 'btn-spacing',
    'type'           => 'spacing',
    'output'         => array('.btn-default'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Button Padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '10px', 
        'padding-right'   => '25px', 
        'padding-bottom'  => '10px', 
        'padding-left'    => '25px',
        'units'          => 'px', 
    ),
),
            array(
    'id'          => 'btn-typography2',
    'type'        => 'typography', 
    'title'       => __('Button Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('.btn-default'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '26px',
		'color' => '#6b7c93',
		'letter-spacing' => '0.5px'
    ),
        ),
				array(
    'id'       => 'btn-bg-colr',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => '.btn-default'),
    'title'    => __('Button Background', 'redux-framework-demo'), 
    'subtitle' => __('You can set opacity too', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#333',
        'alpha'     => 0.1
    ),
),
				array(
    'id'       => 'btn-bg-colr2',
    'type'     => 'color_rgba',
	'output'    => array('background-color' => '.btn-default:hover'),
    'title'    => __('Button Background On Hover', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
	'default'   => array(
        'color'     => '#333',
        'alpha'     => 0.5
    ),
),
	 array(         
    'id'      => 'btnn-borderradius',
    'type'    => 'box_shadow',
    'title'   => __('Border Radius', 'redux-framework-demo'),
    'units'   => array( 'px', 'em', 'rem' ),
    'output'  => ( '.btn-default' ),
    'opacity' => true,
    'rgba'    => true,
	'preview' => false,
    'default' => array (
        'horizontal'   => '35px', 
    ),
),
		)));
		Redux::setSection( $opt_name, array(
        'title'      => __( 'Page Preload', 'redux-framework-demo' ),
        'desc'       => __('You can create page preload screen here'),
        'id'         => 'page-preloader',
        'subsection' => true,
        'fields'     => array(
		array(
    'id'       => 'preload-switch',
    'type'     => 'switch', 
    'title'    => __('Enable page preloader?', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => true,
),
		 array(
    'id'       => 'preloadertype',
    'type'     => 'image_select',
			'default' => 1,
    'title'    => __('Choose Preloader Type', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'options'  => array(
        '1'      => array(
            'img'   => $styleurl.'/includes/headers/images/preload1.jpg'
        ),
        '2'      => array(
            'img'   => $styleurl.'/includes/headers/images/preload2.jpg'
        ),
		'3'      => array(
            'img'   => $styleurl.'/includes/headers/images/preload3.jpg'
        )
    ),
	'required' => array('preload-switch','equals','1'),
        ),
	array(
    'id'        => 'preload-bg',
    'type'      => 'color_rgba',
	'required' => array('preload-switch','equals','1'),
    'title'     => 'Preloader Background Color',
	'output' => array('background-color' => 'div#loading'),
    'options'       => array(
        'show_input'                => true,
        'show_initial'              => false,
        'show_alpha'                => true,
        'show_palette'              => true,
        'show_palette_only'         => false,
        'show_selection_palette'    => false,
        'max_palette_size'          => 3,
        'allow_empty'               => false,
        'clickout_fires_change'     => true,
        'show_buttons'              => true,
                            ),                        
                     ),	
		array(
    'id'        => 'preload-bg-c',
    'type'      => 'color_rgba',
	'required' => array('preload-switch','equals','1'),
    'title'     => 'Background Color Of Objects',
	'output' => array('background-color' => 'div#loading div.object1, div#loading div.object2, div#loading div.object3'),
    'options'       => array(
        'show_input'                => true,
        'show_initial'              => false,
        'show_alpha'                => true,
        'show_palette'              => true,
        'show_palette_only'         => false,
        'show_selection_palette'    => false,
        'max_palette_size'          => 3,
        'allow_empty'               => false,
        'clickout_fires_change'     => true,
        'show_buttons'              => true,
                            ),                        
                     ),	
            array(
                'id'            => 'loading-delay',
                'type'          => 'slider',
                'title'         => __( 'Delay Loading Screen', 'redux-framework-demo' ),
                'subtitle'      => __( 'Some pages may load too quickly, with delay you can make loading lasts longer, for nicer animation', 'redux-framework-demo' ),
                'desc'          => __( 'Value 500 means delay for 500 miliseconds', 'redux-framework-demo' ),
                'default'       => 100,
                'min'           => 0,
                'step'          => 1,
                'max'           => 1000,
                'display_value' => 'label'
            ),		
            array(
                'id'            => 'anims-delay',
                'type'          => 'slider',
                'title'         => __( 'Fade Duration', 'redux-framework-demo' ),
                'subtitle'      => __( 'Fade out animation duration for preloader', 'redux-framework-demo' ),
                'desc'          => __( 'In miliseconds', 'redux-framework-demo' ),
                'default'       => 500,
                'min'           => 0,
                'step'          => 1,
                'max'           => 1500,
                'display_value' => 'label'
            ),			
		)
		));
Redux::setSection( $opt_name, array(
        'title' => __( 'Typography', 'redux-framework-demo' ),
        'id'    => 'basic3',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-text-height'
    ) );
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Headings', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'opt-text-subsection-3',
        'subsection' => true,
        'fields'     => array(
            array(
    'id'          => 'h1tag',
    'type'        => 'typography', 
    'title'       => __('H1 Tags', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('h1'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '700', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '62px', 
        'line-height' => '62px',
		'color' => '#303030',
		'letter-spacing' => '-0.5px'
    ),
        ),
		            array(
    'id'          => 'h2tag',
    'type'        => 'typography', 
    'title'       => __('H2 Tags', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('h2, .blogpost h2 a, div.posts-nav a'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '700', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '42px', 
        'line-height' => '42px',
		'color' => '#303030',
		'letter-spacing' => '-0.5px'
    ),
        ),
				            array(
    'id'          => 'h3tag',
    'type'        => 'typography', 
    'title'       => __('H3 Tags', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('h3'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '700', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '32px', 
        'line-height' => '32px',
		'color' => '#303030',
		'letter-spacing' => '-0.5px'
    ),
        ),
				            array(
    'id'          => 'h4tag',
    'type'        => 'typography', 
    'title'       => __('H4 Tags', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('h4'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '700', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '22px', 
        'line-height' => '22px',
		'color' => '#303030',
		'letter-spacing' => '-0.5px'
    ),
        ),
				            array(
    'id'          => 'h5tag',
    'type'        => 'typography', 
    'title'       => __('H5 Tags', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'letter-spacing' => true,
    'output'      => array('h5'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Montserrat', 
        'google'      => true,
        'font-size'   => '18px', 
        'line-height' => '22px',
		'color' => '#303030',
		'letter-spacing' => '-0.5px'
    ),
        )
		
        )
    ) );
	    Redux::setSection( $opt_name, array(
        'title'      => __( 'Other Tags', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'opt-text-subsection',
        'subsection' => true,
        'fields'     => array(
        array(
    'id'          => 'paragraphs',
    'type'        => 'typography', 
    'title'       => __('Paragraph', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'letter-spacing' => true,
	'color' => true,
	'text-align' => false,
    'output'      => array('p, ol a, input[type="text"], textarea, input[type="search"], td, th'),
    'units'       =>'px',
    'subtitle'    => __('(pretty much main text on site)', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Open Sans', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '24px',
		'color' => '#474747',
		'letter-spacing' => '0.5px'
    ),
        ),
		        array(
    'id'          => 'rowsbuttons',
    'type'        => 'typography', 
    'title'       => __('Buttons Text', 'redux-framework-demo'),
	'desc' => __('Default buttons behavior, you can also manage button properties in button shortcode', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'color' => true,
	'text-align' => false,
	'font-size' => false,
	'line-height' => false,
    'output'      => array('.btn-big, .btn-small, .btn-medium, .btn-regular, .btn-big:hover, .btn-small:hover, .btn-medium:hover, .btn-regular:hover'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-weight'  => '700', 
        'font-family' => 'Montserrat', 
        'google'      => true,
		'color' => '#FFFFFF'
    ),
        ),
		 array(
    'id'          => 'ullist',
    'type'        => 'typography', 
    'title'       => __('Lists', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'letter-spacing' => true,
	'color' => true,
	'text-align' => true,
    'output'      => array('section ul, .tagcloud a, .widget ul li a:not(:hover), section ul li, section ol, section ol li, aside ul li, aside ul li a, aside ol li, aside ol a, div.footer-widget ul, div.footer-widget ol, div.footer-widget ul a:not(:hover), div.footer-widget ol a:not(:hover)'),
    'units'       =>'px',
    'subtitle'    => __('Works for unordered and ordered list', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Open Sans', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '28px',
		'color' => '#313131',
		'letter-spacing' => '0.5px'
    ),
        ),
        )
    ) );
    Redux::setSection( $opt_name, array(
        'title' => __( 'Footer Creator', 'redux-framework-demo' ),
        'id'    => 'footercreator',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-tasks',
		 'fields' => array(
		array(
    'id'       => 'f-widgets-align',
    'type'     => 'button_set', 
    'title'    => __('Widgets Alignment', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '1',
	'options' => array(
        '1' => 'Align Center', 
        '2' => 'Align Left',
     ), 
),
		 				 array(
    'id'       => 'footerID',
    'type'     => 'image_select',
	'width' => '100',
	'class' => 'bigimgsba',
			'default' => 1,
    'title'    => __('Please choose footer design', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'options'  => array(
        '1'      => array(
            'alt'   => '1 Centered Widget + Footer Bar', 
            'img'   => $styleurl.'/includes/footers/images/footer1.png'
        ),
        '2'      => array(
             'alt'   => 'Footer Bar Only', 
            'img'   => $styleurl.'/includes/footers/images/footer2.jpg'
        )
    )
        )
		 
		 )
    ) );
 Redux::setSection( $opt_name, array(
        'title'      => __( 'Footer Bar', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'footer-bar',
        'subsection' => true,
        'fields'     => array(
				array(
    'id'       => 'footerbar-switch',
    'type'     => 'switch', 
    'title'    => __('Use footer bar?', 'redux-framework-demo'),
    'subtitle' => __('Footer bar is bar used at bottom of page, usually holding copyright text', 'redux-framework-demo'),
    'default'  => true
	),
				array(
    'id'       => 'footerbarswitch',
	'required' => array('footerbar-switch','equals','1'),
    'type'     => 'button_set',
    'title'    => __('Footer Bar background color', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'desc'     => __('', 'redux-framework-demo'),
    //Must provide key => value pairs for options
    'options' => array(
        '1' => 'Use Scheme Color', 
        '2' => 'Choose Color'
                      ), 
    'default' => '1'
                      ),
				array(
    'id'        => 'footer-bar-bg',
    'type'      => 'color_rgba',
	'required' => array('footerbarswitch','equals','2'),
    'title'     => 'Footer Bar Background Color',
	'output' => array('background-color' => 'body footer'),
    'options'       => array(
        'show_input'                => true,
        'show_initial'              => false,
        'show_alpha'                => true,
        'show_palette'              => true,
        'show_palette_only'         => false,
        'show_selection_palette'    => false,
        'max_palette_size'          => 5,
        'allow_empty'               => false,
        'clickout_fires_change'     => true,
        'show_buttons'              => true,
                            ),                        
                     ),			
       array(
           'id'               => 'footerbar-editor',
           'type'             => 'editor',
		   'required' => array('footerbar-switch','equals','1'),
           'title'            => __('Footer Bar Content', 'redux-framework-demo'), 
           'subtitle'         => __('', 'redux-framework-demo'),
           'default'          => '<p>Copyright @ your site. Powered by Designr Theme</p>',
           'args'   => array(
           'teeny'            => true,
           'textarea_rows'    => 3
                           )
            ),
        array(
    'id'          => 'footerp',
    'type'        => 'typography', 
    'title'       => __('Footer Bar Typography', 'redux-framework-demo'),
    'google'      => true, 
    'font-backup' => true,
	'letter-spacing' => true,
	'required' => array('footerbar-switch','equals','1'),
	'color' => true,
	'text-align' => false,
    'output'      => array('div.footer-bar .container, div.footer-bar p'),
    'units'       =>'px',
    'subtitle'    => __('', 'redux-framework-demo'),
    'default'     => array(
        'font-style'  => '400', 
        'font-family' => 'Open Sans', 
        'google'      => true,
        'font-size'   => '16px', 
        'line-height' => '60px',
		'color' => '#fff',
		'letter-spacing' => '0.5px'
    ),
        ),			
		array(
    'id'             => 'footerbar-spacing',
    'type'           => 'spacing',
    'output'         => array('div.footer-bar'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Footer Bar padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
	'required' => array('footerbar-switch','equals','1')
),						   
		)
		));
 Redux::setSection( $opt_name, array(
        'title'      => __( 'Other Settings', 'redux-framework-demo' ),
        'desc'       => __(''),
        'id'         => 'footer-other-settings',
        'subsection' => true,
        'fields'     => array(
							 array(
    'id'       => 'usebgswitch',
    'type'     => 'button_set',
    'title'    => __('Footer background color', 'redux-framework-demo'),
    'subtitle' => __('', 'redux-framework-demo'),
    'desc'     => __('', 'redux-framework-demo'),
    //Must provide key => value pairs for options
    'options' => array(
        '1' => 'Use Scheme Color', 
        '2' => 'Choose Color'
     ), 
    'default' => '1'
                                   ),
			array(
    'id'             => 'footer-spacing',
    'type'           => 'spacing',
    'output'         => array('footer section#footer'),
    'mode'           => 'padding',
    'units'          => array('px'),
    'units_extended' => false,
    'title'          => __('Footer padding', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'padding-top'     => '0px', 
        'padding-right'   => '0px', 
        'padding-bottom'  => '0px', 
        'padding-left'    => '0px',
        'units'          => 'px', 
    ),
),								   
				array(
    'id'        => 'footer-bg-color',
    'type'      => 'color_rgba',
	'required' => array('usebgswitch','equals','2'),
    'title'     => 'Footer Background Color',
	'output' => array('background-color' => 'footer section#footer'),
    'options'       => array(
        'show_input'                => true,
        'show_initial'              => false,
        'show_alpha'                => true,
        'show_palette'              => true,
        'show_palette_only'         => false,
        'show_selection_palette'    => false,
        'max_palette_size'          => 5,
        'allow_empty'               => false,
        'clickout_fires_change'     => true,
        'show_buttons'              => true,
                            ),                        
                     ),
	         array(
    'id'             => 'opt-spacing',
    'type'           => 'spacing',
    'output'         => array('.footer-widget'),
    'mode'           => 'margin',
    'units'          => 'px',
	'top' => false,
	'left' => false,
	'bottom' => false,
    'units_extended' => 'false',
    'title'          => __('Footer Widgets Margin Right', 'redux-framework-demo'),
    'subtitle'       => __('', 'redux-framework-demo'),
    'desc'           => __('', 'redux-framework-demo'),
    'default'            => array(
        'margin-right'   => '100px'
    )
    ),
array(
    'id'       => 'footertitle',
    'type'     => 'color',
	'output'    => array('color' => 'footer h3'),
    'title'    => __('Widget Titles Color', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#ffffff',
    'validate' => 'color',
	'transparent' => false
),	
array(
    'id'       => 'footercc',
    'type'     => 'color',
	'output'    => array('color' => 'section#footer p'),
    'title'    => __('Widget Content Color', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#ffffff',
    'validate' => 'color',
	'transparent' => false
),	
array(
    'id'       => 'footerwcc',
    'type'     => 'color',
	'output'    => array('color' => 'div.footer-widget ul, div.footer-widget ol, div.footer-widget ul a:not(:hover), div.footer-widget ol a:not(:hover)'),
    'title'    => __('Footer Widget Lists Color', 'redux-framework-demo'), 
    'subtitle' => __('', 'redux-framework-demo'),
    'default'  => '#ffffff',
    'validate' => 'color',
	'transparent' => false,
	'important' => true
),	
		)
		));	
    add_filter('redux/options/designr/compiler', 'designr_compiler_action', 10, 3);
    if ( ! function_exists( 'designr_compiler_action' ) ) {
        function designr_compiler_action( $options, $css, $changed_values) {
    global $wp_filesystem;
 
    $filename = dirname(__FILE__) . '/designr-style.css';
 
    if( empty( $wp_filesystem ) ) {
        require_once( ABSPATH .'/wp-admin/includes/file.php' );
        WP_Filesystem();
    }
 
    if( $wp_filesystem ) {
        $wp_filesystem->put_contents(
            $filename,
            $css,
            FS_CHMOD_FILE // predefined mode settings for WP files
        );
    } else { echo 'WP_Filesystem doesnt work';}
}
    }		