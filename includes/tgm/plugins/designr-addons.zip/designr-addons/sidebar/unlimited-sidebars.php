<?php
add_filter( 'designr_sidebar', 'designr_display_sidebar' );
add_action( 'init', 'designr_options_init' );
add_action( 'admin_init', 'designr_options_admin_init' );
add_action( 'admin_menu', 'designr_options_add_page' );

function designr_display_sidebar( $default_sidebar ) {

  $q_object = get_queried_object();
  $sidebars = get_option( 'designr_sidebars' );
  if($sidebars!=""){
  foreach ( $sidebars as $id => $sidebar ) {
    if ( is_singular() ) {
      if ( array_key_exists( 'pages', $sidebar ) ) {
        if ( array_key_exists( 'children', $sidebar ) && $sidebar['children'] == 'on' ) {
          $child = array_key_exists( $q_object->post_parent, $sidebar['pages'] );
        } else {
          $child = false;
        }
        if ( array_key_exists( $q_object->ID, $sidebar['pages'] ) || $child ) {
          return $id;
        }
      }
    } elseif ( is_home() ) {
      if ( array_key_exists( 'index-blog', $sidebar ) && $sidebar['index-blog'] == 'on' ) {
        return $id;
      }
    } elseif ( is_tax() || is_category() || is_tag() ) {
      if ( array_key_exists( 'taxonomies', $sidebar ) ) {
        if ( array_key_exists( $q_object->term_id, $sidebar['taxonomies'] ) ) {
          return $id;
        }
      }
    } elseif ( x_is_shop() ) {
      if ( array_key_exists( 'index-shop', $sidebar ) && $sidebar['index-shop'] == 'on' ) {
        return $id;
      }
    }
  }
}
  return $default_sidebar;

}



// Add Options Page
// =============================================================================

function designr_options_add_page() {
  add_theme_page( 'Sidebars', 'Sidebars', 'edit_theme_options', 'designr_sidebars', 'designr_sidebars_do_page' );
}



// Options Init
// =============================================================================

//
// Registers all sidebars for use on the front-end and Widgets page.
//

function designr_options_init() {
  $sidebars = get_option( 'designr_sidebars' );
  if ( is_array( $sidebars ) ) {
    foreach ( (array) $sidebars as $id => $sidebar ) {
      unset( $sidebar['pages'] );
      $sidebar['id'] = $id;
      register_sidebar( $sidebar );
    }
  }
}



// Options Admin Init
// =============================================================================

//
// Adds the metaboxes to the main options page for the sidebars in the database.
//

function designr_options_admin_init() {

  wp_enqueue_script( 'common' );
  wp_enqueue_script( 'wp-lists' );
  wp_enqueue_script( 'postbox' );

  // Register setting to store all the sidebar options in the *_options table.
  register_setting( 'designr_sidebars_options', 'designr_sidebars', 'designr_sidebars_validate' );

  $sidebars = get_option( 'designr_sidebars' );

  if ( is_array( $sidebars ) && count ( $sidebars ) > 0 ) {
    foreach ( $sidebars as $id => $sidebar ) {
      add_meta_box(
        esc_attr( $id ),
        esc_html( $sidebar['name'] ),
        'designr_sidebar_do_meta_box',
        'designr_sidebars',
        'normal',
        'default',
        array(
          'id'      => esc_attr( $id ),
          'sidebar' => $sidebar
        )
      );
      unset( $sidebar['pages'] );
      $sidebar['id'] = esc_attr( $id );
      register_sidebar( $sidebar );
    }
  } else {
    add_meta_box( 'designr-sidebar-no-sidebars', 'No sidebars', 'designr_sidebar_no_sidebars', 'designr_sidebars', 'normal', 'default' );
  }


  //
  // Sidebar metaboxes.
  //

  add_meta_box( 'designr-sidebar-add-new-sidebar', 'Add New Sidebar', 'designr_sidebar_add_new_sidebar', 'designr_sidebars', 'side', 'default' );

}

function designr_sidebar_no_sidebars() {
	?>
	<p>
	<?php
  echo __('You have not added any sidebars. Please add new sidebar by using form on right side --->','designr');
  ?>
  </p>
  <?php
}



// Callbacks
// =============================================================================

//
// Creates the theme page and adds a spot for the metaboxes.
//

function designr_sidebars_do_page() {
  ?>
  <div class="wrap designr-sidebars">
    <h2><?php echo __('Manage Sidebars','designr');?></h2>
    <?php designr_sidebar_update_message(); ?>
    <div id="poststuff">
      <div id="post-body" class="metabox-holder columns-2">
        <div id="post-body-content">
          <form method="post" action="options.php">
            <?php settings_fields( 'designr_sidebars_options' ); ?>
            <?php do_meta_boxes( 'designr_sidebars', 'normal', null ); ?>
          </form>
        </div>
        <div id="postbox-container-1" class="postbox-container">
          <?php do_meta_boxes( 'designr_sidebars', 'side', null ); ?>
        </div>
      </div>
    </div>
  </div>
  <?php
}


//
// Adds the content of the metaboxes for each sidebar.
//

function designr_sidebar_do_meta_box( $post, $metabox ) {

  $sidebars   = get_option( 'designr_sidebars' );
  $sidebar_id = esc_attr( $metabox['args']['id'] );
  $sidebar    = $sidebars[$sidebar_id];
  
  if ( ! isset( $sidebar['pages']      ) ) { $sidebar['pages']      = array(); }
  if ( ! isset( $sidebar['taxonomies'] ) ) { $sidebar['taxonomies'] = array(); }

  $options_fields = array(
    'name'          => array( 'Name', '' ),
    'description'   => array( 'Description', '' ),
    'sidebar-id'    => array( 'ID', '' ),
    'before_title'  => array( 'Before Title', '<h2 class="widget-title">' ),
    'after_title'   => array( 'After Title', '</h2>' ),
    'before_widget' => array( 'Before Widget', '<aside id="%1$s" class="widget %2$s">' ),
    'after_widget'  => array( 'After Widget', '</aside>' )
  );

  $get_posts = new WP_Query;

  $posts = $get_posts->query( array(
    'offset'                 => 0,
    'order'                  => 'ASC',
    'orderby'                => 'title',
    'posts_per_page'         => -1,
    'post_type'              => array( 'page', 'post', 'portfolios' ),
    'suppress_filters'       => true,
    'update_post_term_cache' => false,
    'update_post_meta_cache' => false
  ) );


    $taxonomies = get_terms( array(
      'category',
      'portfolio-category',
    ) );

  ?>

  <div class="designr-lists">
    <div class="wp-tab-wrapper">
      <ul class="wp-tab-bar">
        <li class="wp-tab-active">All Pages and Posts</li>
      </ul>
      <div class="wp-tab-panel">
        <ul id="entry-checklist" class="entry-checklist categorychecklist">
          <?php foreach ( $posts as $post ) : ?>
          <li>
            <label>
            <?php $checked = designr_checked_list_item( $post->ID, $sidebar['pages'] ); ?>
            <input type="checkbox" class="menu-item-checkbox" name="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][pages][<?php echo esc_attr( $post->ID ); ?>]" value="<?php echo esc_attr( $post->post_title ); ?>"<?php echo esc_attr($checked); ?>>
            <?php echo esc_html( $post->post_title ); ?>
            </label>
          </li>
          <?php endforeach; wp_reset_postdata(); ?>
        </ul>
      </div>
    </div>
  </div>
  <div class="designr-sidebar-options">
    <table class="form-table">
      <?php foreach ( $options_fields as $id => $label ) : ?>
      <tr valign="top">
        <?php if ( $id == 'before_title' || $id == 'after_title' || $id == 'before_widget' || $id == 'after_widget' ) : ?>
          <th class="hidden" scope="row"><label for="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]"><?php echo esc_html( $label[0] ); ?></label></th>
          <td class="hidden"><input id="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" class="regular-text" type="text" name="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_html( $label[1] ); ?>" readonly></td>
        <?php else : ?>
          <th scope="row"><label for="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]"><?php echo esc_html( $label[0] ); ?></label></th>
          <td>
            <?php if ( $id == 'children' || $id == 'index-blog' || $id == 'index-shop' ) : ?>
              <?php $checked = ( array_key_exists( $id, $sidebar ) ) ? checked( $sidebar[$id], 'on', false ) : ''; ?>
              <label>
                <input type="checkbox" name="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" value="on" id="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" <?php echo esc_attr($checked); ?>>
                
              </label>
            <?php elseif ( $id == 'sidebar-id' ) : ?>
              <input id="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" class="regular-text" type="text" name="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_html( $sidebar[$id] ); ?>" readonly>
            <?php else : ?>
              <input id="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" class="regular-text" type="text" name="designr_sidebars[<?php echo esc_attr( $sidebar_id ); ?>][<?php echo esc_attr( $id ); ?>]" value="<?php echo esc_html( $sidebar[$id] ); ?>">
            <?php endif; ?>
          </td>
        <?php endif; ?>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <div class="sidebar-submit-box">
    <input type="submit" class="button-primary" value="Update Sidebar">
    <label><input type="checkbox" name="designr_sidebars[delete]" value="<?php echo esc_attr( $sidebar_id ); ?>"> <?php echo __('Delete this sidebar?','designr');?></label>
    <br>
  </div>
  <?php
}



// Validation
// =============================================================================

//
// Handles all the post data (adding, updating, deleting sidebars).
//

function designr_sidebars_validate( $input ) {

  if ( isset( $input['add_sidebar'] ) ) {

    $sidebars = get_option( 'designr_sidebars' );

    if ( ! empty( $input['add_sidebar'] ) ) {
      $sidebar_id_slug = 'designr-sidebar-' . sanitize_title_with_dashes( remove_accents( $input['add_sidebar'] ) );
      $sidebars[$sidebar_id_slug] = array(
        'name'          => esc_html( $input['add_sidebar'] ),
        'description'   => '',
        'sidebar-id'    => $sidebar_id_slug,
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget'  => '</aside>',
        'pages'         => array(),
        'taxonomies'    => array(),
        'children'      => 'off',
        'index-blog'    => 'off',
        'index-shop'    => 'off'
      );
    }

    // Remove array index from old versions that doesn't need to be there.
    if ( array_key_exists( 'sidebar-id', $sidebars ) ) {
      unset( $sidebars['sidebar-id'] );
    }

    return $sidebars;

  }

  if ( isset( $input['delete'] ) ) {
    foreach ( (array) $input['delete'] as $delete_id ) {
      unset( $input[$delete_id] );
    }
    unset( $input['delete'] );
    return $input;
  }

  return $input;

}



// Add New Sidebar
// =============================================================================

//
// Handles the content of the metabox, which allows adding new sidebars.
//

function designr_sidebar_add_new_sidebar() {
  ?>
  <form method="post" action="options.php" id="add-new-sidebar">
    <?php settings_fields( 'designr_sidebars_options' ); ?>
    <p><?php echo __('Enter name of a new sidebar below.','designr');?></p>
    <input id="designr_sidebars[add_sidebar]" class="text" type="text" name="designr_sidebars[add_sidebar]" value="">
    <input type="submit" class="button-primary" value="Add Sidebar">
  </form>
  <?php
}



// Update Message
// =============================================================================

function designr_sidebar_update_message() {

  if ( ! isset( $_REQUEST['settings-updated'] ) ) :
    $_REQUEST['settings-updated'] = false;
  endif;

  if ( $_REQUEST['settings-updated'] !== false ) :
    echo '<div class="updated fade"><p><strong>';
	echo __('Sidebar is saved!','designr');
	?>
	</strong> <?php echo __('You can now go manage the','designr');?> <a href="' . get_admin_url() . 'widgets.php"><?php echo __('widgets','designr');?></a> <?php echo __('for this sidebar.','designr');?></p></div>';
  <?php
  endif;

}



// Checked List Item
// =============================================================================

function designr_checked_list_item( $needle, $haystack ) {

  if ( array_key_exists( $needle, $haystack ) ) {
    $output = ' checked="checked"';
  } else {
    $output = '';
  }

  return $output;

}



// Print Scripts in Footer
// =============================================================================

function designr_print_scripts_in_footer() {
  echo '<script>jQuery(document).ready(function(){ postboxes.add_postbox_toggles(pagenow); });</script>';
}

add_action( 'admin_footer-appearance_page_designr_sidebars', 'designr_print_scripts_in_footer' );