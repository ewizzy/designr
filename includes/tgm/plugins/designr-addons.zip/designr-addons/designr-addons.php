<?php
/**
 * Plugin Name: Designr Addons
 * Description: Frontend Elements and core part of Designr theme.
 * Plugin URI:  http://themeforest.net/user/ewizz/portfolio
 * Version:     2.3
 * Author:      ewizz
 * Author URI:  http://themeforest.net/user/ewizz
 * Text Domain: designr
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'ELEMENTOR_designr__FILE__', __FILE__ );

/**
 * 
 *
 * Load the plugin after Elementor (and other plugins) are loaded.
 *
 * @since 1.0.0
 */
function designr_load() {
	// Load localization file
	//load_plugin_textdomain( 'designr' );
	include 'admin/admin-init.php';
	// load cmb2
	include 'load-metaboxes.php';
	//load mega-menu
	include 'mega-menu/mega-menu.php';
	//load sidebars
    include 'sidebar/unlimited-sidebars.php';
	// Require the main plugin file
	require( __DIR__ . '/plugin.php' );
}
add_action( 'plugins_loaded', 'designr_load' );
function designr_woo_get_categories(){
    $terms = get_terms( array(
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
    ));
    
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
    foreach ( $terms as $term ) {
        $options[ $term->slug ] = $term->name;
    }
    return $options;
    }
    
    
}

function designr_woo_get_product_by_id(){
    $postlist = get_posts(array(
        'post_type' => 'product',
        'showposts' => 999,
    ));
    $posts = array();
    
    if ( ! empty( $postlist ) && ! is_wp_error( $postlist ) ){
    foreach ( $postlist as $post ) {
        $options[ $post->ID ] = $post->post_title;
    }
    return $options;
    
    }
}