<?php
namespace HelloWorld\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;

if (!defined('ABSPATH')) exit; // Exit if accessed directly


class Designr_Pricing_Tables extends Widget_Base {


    public function __construct($data = [], $args = null) {
        parent::__construct($data, $args);

        add_shortcode('da-pricing-tables', array($this, 'designr_addons_pricing_tables'));
    }

    public function designr_addons_pricing_tables($atts, $content = null, $tag) {

        $title = $value = '';

        extract(shortcode_atts(array(
            'title' => '',
            'value' => ''

        ), $atts));

        ob_start();

        ?>

        <div class="designr-addons-pricing-item">

            <div class="designr-addons-title">

                <?php echo esc_html($title); ?>

            </div>

            <div class="designr-addons-value-wrap">

                <div class="designr-addons-value">

                    <?php echo esc_html($value); ?>

                </div>

            </div>

        </div>

        <?php


        $output = ob_get_clean();

        return $output;
    }

    public function get_name() {
        return 'designr-addons-pricing-table';
    }

    public function get_title() {
        return __('Pricing Tables', 'designr-addons');
    }

    public function get_icon() {
        return 'eicon-price-table';
    }

    public function get_categories() {
        return [ 'designr-elements' ];
    }

    public function get_script_depends() {
        return [];
    }

    protected function _register_controls() {

        $this->start_controls_section(
            'section_pricing_table',
            [
                'label' => __('Pricing Table', 'designr-addons'),
            ]
        );

        $this->add_control(
            'pricing_heading',
            [
                'label' => __('Pricing Tables', 'designr-addons'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'designr_price_tables',
            [
                'type' => Controls_Manager::REPEATER,
                'fields' => [
				  [
                        'name' => 'designr_tagline',
                        'type' => Controls_Manager::TEXT,
                        'label' => __('Tagline', 'designr-addons'),
                        'description' => __('Add taglines like "Best Value"', 'designr-addons'),
						'label_block' => true,
                    ],
                    [
                        'name' => 'designr_pricing_title',
                        'type' => Controls_Manager::TEXT,
                        'label' => __('Title', 'designr-addons'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'designr_price_tag',
                        'type' => Controls_Manager::TEXT,
                        'label' => __('Price', 'designr-addons'),
						'label_block' => true,
                    ],
			[
			'name' => 'designr_pricing_content',
				'label' => '',
				'type' => Controls_Manager::WYSIWYG,
				'default' => __( 'Add any content<br />with HTML allowed<br /><strong>Awesome!</strong>', 'elementor' ),
			],
					 [
                        'name' => 'designr_button_text',
                        'type' => Controls_Manager::TEXT,
                        'label' => __('Button Text', 'designr-addons'),
                    ],

                    [
                        'name' => 'designr_button_url',
                        'label' => __('Button URL', 'designr-addons'),
                        'type' => Controls_Manager::URL,
                        'label_block' => true,
                        'default' => [
                            'url' => ''
                        ],
                        'placeholder' => __('http://yoursite.com', 'designr-addons'),
                    ],
    [
	'name' => 'animation_style',
        'label' => __( 'Entrance Animation', 'designr-addons' ),
        'type' => Controls_Manager::ANIMATION,
        'prefix_class' => 'animated ',
    ],
	[
                        'name' => 'designr_highlight',
                        'label' => __('Make this plan featured?', 'designr-addons'),
                        'type' => Controls_Manager::SWITCHER,
                        'label_off' => __('No', 'designr-addons'),
                        'label_on' => __('Yes', 'designr-addons'),
                        'return_value' => 'yes',
                        'default' => 'no',
                    ],

                ],
                'title_field' => '{{{ designr_pricing_title }}}',
            ]
        );

        $this->end_controls_section();
        $this->start_controls_section(
            'table_style',
            [
                'label' => __( 'Tables Style', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_control('align',
					[
			'name' => 'align',
				'label' => __( 'Text Align', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .designr-addons-pricing-table *, {{WRAPPER}} .designr-addons-pricing-table a, {{WRAPPER}} .designr-addons-pricing-table p' => 'text-align: {{VALUE}}!important;',
				],
			]);
			$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'tables_bg_color',
				'selector' => '{{WRAPPER}} .designr-addons-pricing-table',
			]
		);
		$this->add_control(
       'tables_box_shadow',
       [
        'label' => __( 'Box Shadow', 'designr-addons' ),
        'type' => Controls_Manager::BOX_SHADOW,
        'default' => [
            'color' => 'rgba(0,0,0,.12)',
        ],
        'selectors' => [
            '{{WRAPPER}} .designr-addons-pricing-table' => 'box-shadow: {{HORIZONTAL}}px {{VERTICAL}}px {{BLUR}}px {{SPREAD}}px {{COLOR}};',
        ],
    ]
);
		$this->add_control(
            'designr_table_radius',
            [
                'label' => __('Tables Border Radius', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px','%'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
            'designr_table_margin',
            [
                'label' => __('Tables Margin', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
				$this->add_control(
            'designr_table_padding',
            [
                'label' => __('Tables Padding', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'default' => [
                    'top' => 15,
                    'right' => 30,
                    'bottom' => 15,
                    'left' => 30,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
			'hover_animation_tables',
			[
				'label' => __( 'Tables Hover Animation', 'designr-addons' ),
				'type' => Controls_Manager::HOVER_ANIMATION,
			]
		);
		$this->end_controls_section();
		 $this->start_controls_section(
            'table_style2',
            [
                'label' => __( 'Featured Table Style', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'f_tables_bg_color',
				'selector' => '{{WRAPPER}} .designr-addons-pricing-table.designr-plan-highlighted',
			]
		);
		$this->add_control(
            'f_designr_table_padding',
            [
                'label' => __('Table Padding', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'default' => [
                    'top' => 20,
                    'right' => 40,
                    'bottom' => 20,
                    'left' => 40,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table.designr-plan-highlighted' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
            'f_designr_table_margin',
            [
                'label' => __('Table Margin', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'default' => [
                    'top' => -5,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table.designr-plan-highlighted' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		
		$this->end_controls_section();
		        $this->start_controls_section(
            'section_plan_tagline',
            [
                'label' => __( 'Plan Tagline', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'plan_tagline_color',
            [
                'label' => __( 'Color', 'designr-addons' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-title-wrap .designr-addons-tagline' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'plan_tagline_bg_color',
            [
                'label' => __( 'Background Color', 'designr-addons' ),
                'type' => Controls_Manager::COLOR,
				'default' => '#fafafa',
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-title-wrap' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'plan_tagline_typography',
                'selector' => '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-title-wrap .designr-addons-tagline',
            ]
        );
        $this->add_control(
            'plan_tagline_spacing',
            [
                'label' => __('Tagline Padding', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 8,
                    'right' => 15,
                    'bottom' => 8,
                    'left' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-title-wrap'=> 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_pricing_style',
            [
                'label' => __( 'Title', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'designr_title_color',
            [
                'label' => __( 'Color', 'designr-addons' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-title-wrap .designr-addons-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'designr_title_typography',
                'selector' => '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-title-wrap .designr-addons-title',
            ]
        );


        $this->end_controls_section();
        $this->start_controls_section(
            'section_plan_price',
            [
                'label' => __( 'Price', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'plan_price_color',
            [
                'label' => __( 'Color', 'designr-addons' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-price-wrap span' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'plan_price_bg_color',
            [
                'label' => __( 'Background Color', 'designr-addons' ),
                'type' => Controls_Manager::COLOR,
				'default' => '#fcfcfc',
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-price-wrap' => 'background: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'plan_price_typography',
                'selector' => '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-price-wrap span',
            ]
        );
        $this->add_control(
            'plan_price_spacing',
            [
                'label' => __('Price Padding', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 8,
                    'right' => 15,
                    'bottom' => 8,
                    'left' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-price-wrap'=> 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->end_controls_section();
        $this->start_controls_section(
            'section_contenta_area',
            [
                'label' => __( 'Content', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );	
		 $this->add_control(
            'content_spacing',
            [
                'label' => __('Content Margin', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 10,
                    'right' => 0,
                    'bottom' => 10,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-content-wrap p'=> 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->add_control(
            'content_spacing2',
            [
                'label' => __('Content Padding', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 8,
                    'right' => 15,
                    'bottom' => 8,
                    'left' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-content-wrap p'=> 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
		$this->end_controls_section();
        $this->start_controls_section(
            'section_buy_button',
            [
                'label' => __( 'Buy Button', 'designr-addons' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_control(
            'purchase_button_spacing',
            [
                'label' => __('Button Padding', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 8,
                    'right' => 15,
                    'bottom' => 8,
                    'left' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-button-wrap a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
 $this->add_control(
            'purchase_button_spacing2',
            [
                'label' => __('Button Margin', 'designr-addons'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px'],
                'default' => [
                    'top' => 20,
                    'right' => 0,
                    'bottom' => 20,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-button-wrap a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'button_custom_color',
            [
                'label' => __('Button Color', 'designr-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-button-wrap a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_custom_hover_color',
            [
                'label' => __('Button Background Color On Hover', 'designr-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-button-wrap a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'button_custom_hover_text',
            [
                'label' => __('Button Text Color On Hover', 'designr-addons'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-button-wrap a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'purchase_button_typography',
                'selector' => '{{WRAPPER}} .designr-addons-pricing-table .designr-addons-button-wrap a',
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {

        $settings = $this->get_settings();

        if (empty($settings['designr_price_tables']))
            return;
		$hover_animation_tables = $settings['hover_animation_tables'];
        ?>
        <div class="designr-addons-pricing-tables designr-addons-container">
            <?php

            foreach ($settings['designr_price_tables'] as $current_plan) :

                $titler = esc_html($current_plan['designr_pricing_title']);
                $tagline = esc_html($current_plan['designr_tagline']);
                $price_tag = htmlspecialchars_decode(wp_kses_post($current_plan['designr_price_tag']));
                $pricing_url = (empty($current_plan['designr_button_url']['url'])) ? '#' : esc_url($current_plan['designr_button_url']['url']);
                $pricing_button_text = esc_html($current_plan['designr_button_text']);
                $button_new_window = esc_html($current_plan['designr_button_url']['is_external']);
				$nofollow = esc_html($current_plan['designr_button_url']['nofollow']);
                $highlight = ($current_plan['designr_highlight'] === 'yes');
                $animation_style = $current_plan['animation_style'];
                $price_tag = (empty($price_tag)) ? '' : $price_tag;

                ?>

                <div class="designr-addons-pricing-table<?php echo ($highlight ? ' designr-plan-highlighted' : '');if($animation_style!=""){ echo ' animated '.$animation_style;} if($hover_animation_tables!=""){ echo ' elementor-animation-'.$hover_animation_tables;} ?>">

                    <div class="designr-addons-title-wrap">

                        <?php 
						if (!empty($tagline))
                            echo '<p class="designr-addons-tagline">' . $tagline . '</p>'; 
                        if (!empty($tagline))
                            echo '<p class="designr-addons-title">' . $titler . '</p>'; 
						?>

                    </div>

                    <div class="designr-addons-price-wrap">

                        <span class="designr-addons-price-span">

                            <?php echo wp_kses_post($price_tag); ?>

                        </span>

                    </div>

                    <div class="designr-addons-content-wrap">

                        <?php echo $this->parse_text_editor($current_plan['designr_pricing_content']) ?>

                    </div><!-- .designr-addons-plan-details -->

                    <div class="designr-addons-button-wrap">

                        <a class="designr-addons-button" href="<?php echo esc_url($pricing_url); ?>"<?php if (!empty($button_new_window)) echo ' target="_blank"';if (!empty($nofollow)) echo ' rel="nofollow"'; ?>>
						<?php echo esc_html($pricing_button_text); ?>
						</a>

                    </div>

                </div>
                <!-- .designr-addons-pricing-plan -->

                <?php

            endforeach;

            ?>

        </div><!-- .designr-addons-pricing-table -->

        <div class="designr-addons-clear"></div>

        <?php
    }

    protected function content_template() {
    }

}