<?php
namespace HelloWorld\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Designr_Testimonials extends Widget_Base {

	public function get_name() {
		return 'Testimonials';
	}

	public function get_title() {
		return __( 'Testimonials', 'elementor' );
	}

	public function get_icon() {
		return 'fa fa-users';
	}
	public function get_script_depends() {
		return [ 'jquery-slick' ];
	}
	public function get_categories() {
		return [ 'designr-elements' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_Testimonials',
			[
				'label' => __( 'Testimonials', 'elementor' ),
			]
		);

		$this->add_control(
			'view',
			[
				'label' => __( 'View', 'elementor' ),
				'type' => Controls_Manager::HIDDEN,
				'default' => 'traditional',
			]
		);

		$this->end_controls_section();

		// Content
		$this->start_controls_section(
			'section_style_Testimonials_content',
			[
				'label' => __( 'Content', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'content_content_color',
			[
				'label' => __( 'Content Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_3,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .designr-Testimonials-content *' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'label' => __( 'Typography', 'elementor' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
				'selector' => '{{WRAPPER}} .designr-Testimonials-content *',
			]
		);

		$this->end_controls_section();

		// Image
		$this->start_controls_section(
			'section_style_Testimonials_image',
			[
				'label' => __( 'Image', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'image_size',
			[
				'label' => __( 'Image Size', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 52,
						'max' => 200,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .designr-Testimonials-wrapper .designr-Testimonials-image img' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				]
			]
		);

		$this->end_controls_section();

		// Name
		$this->start_controls_section(
			'section_style_Testimonials_name',
			[
				'label' => __( 'Name', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_text_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .designr-Testimonials-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'label' => __( 'Typography', 'elementor' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .designr-Testimonials-name',
			]
		);

		$this->end_controls_section();

		// Job
		$this->start_controls_section(
			'section_style_Testimonials_job',
			[
				'label' => __( 'Job', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'job_text_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .designr-Testimonials-job' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'job_typography',
				'label' => __( 'Typography', 'elementor' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_2,
				'selector' => '{{WRAPPER}} .designr-Testimonials-job',
			]
		);

		$this->end_controls_section();
		// dots
		$this->start_controls_section(
			'section_style_Testimonials_dots',
			[
				'label' => __( 'Navigation Dots', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'dots_color',
			[
				'label' => __( 'Dots Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} ul.slick-dots li button' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'dots_color2',
			[
				'label' => __( 'Active/Hover Dot Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_2,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} ul.slick-dots li.slick-active button' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		$this->add_render_attribute( 'wrapper', 'class', 'designr-Testimonials-wrapper' );
		$this->add_render_attribute( 'meta', 'class', 'designr-Testimonials-meta' );
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
        <div class="testimonials-mainwrap">
		<?php
$args = array( 'post_type'=>'testimonials','showposts'=>'10' );
$rand_posts = get_posts( $args );
foreach ( $rand_posts as $post ){ 
  setup_postdata( $post );
  ?>
            <div class="single-testimonial">
			<div class="designr-Testimonials-content">
			<?php the_content(); ?>
			</div>

			<div <?php echo $this->get_render_attribute_string( 'meta' ); ?>>
				<div class="designr-Testimonials-meta-inner">
						<div class="designr-Testimonials-image">
						<?php echo get_the_post_thumbnail($post->ID, "designr_testimonial");?>
						</div>
					<div class="designr-Testimonials-details">
							<div class="designr-Testimonials-name"><?php echo get_post_meta( $post->ID, 'designr_name', true ); ?></div>
							<div class="designr-Testimonials-job"><?php echo get_post_meta( $post->ID, 'designr_job', true ); ?></div>
					</div>
				</div>
			</div>
			</div>
	<?php  }  wp_reset_postdata();?>
			</div>
		</div>
	<?php
	$mainjs = "
	jQuery('div.testimonials-mainwrap').slick({
 arrows: false,
 dots: true,
 adaptiveHeight: true,
 cssEase: 'cubic-bezier(0.86, 0, 0.07, 1)',
 draggable: true
  });";
	wp_add_inline_script( 'jquery-slick', $mainjs);
	}

	protected function _content_template() {
	}
}