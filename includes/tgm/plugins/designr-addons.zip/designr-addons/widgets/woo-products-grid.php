<?php
namespace HelloWorld\Widgets;
use Elementor;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
if ( ! defined( 'ABSPATH' ) ) 
	exit; // If this file is called directly, abort.
class Designr_Woo_Products_Grid extends Widget_Base {
	

	public function get_name() {
		return 'WooGrid';
	}

	public function get_title() {
		return esc_html__( 'Woo Grid', 'designr' );
	}

	public function get_icon() {
		return 'eicon-woocommerce';
	}

   public function get_categories() {
		return [ 'designr-elements' ];
	}


	protected function _register_controls() {

		// Content Controls
  		$this->start_controls_section(
  			'designr_section_product_grid_settings',
  			[
  				'label' => esc_html__( 'Grid Settings', 'designr' )
  			]
  		);

		$this->add_control(
			'designr_product_grid_product_filter',
			[
				'label' => esc_html__( 'Filter by:', 'designr' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'recent-products',
				'options' => [
				    'sale-products' => esc_html__( 'Sale Products', 'designr' ),
					'recent-products' => esc_html__( 'Recent Products', 'designr' ),
					'best-selling-products' => esc_html__( 'Best Selling Products', 'designr' ),
					'featured-products' => esc_html__( 'Featured Products', 'designr' ),
					'top-products' => esc_html__( 'Top Rated Products', 'designr' ),
				],
			]
		);

		$this->add_control(
			'designr_product_grid_column',
			[
				'label' => esc_html__( 'Columns', 'designr' ),
				'type' => Controls_Manager::SELECT,
				'default' => '3',
				'options' => [
					'1' => esc_html__( '1', 'designr' ),
					'2' => esc_html__( '2', 'designr' ),
					'3' => esc_html__( '3', 'designr' ),
					'4' => esc_html__( '4', 'designr' ),
					'5' => esc_html__( '5', 'designr' ),
					'6' => esc_html__( '6', 'designr' ),
				],
			]
		);

		$this->add_control(
		  'designr_product_grid_products_count',
		  [
		     'label'   => __( 'Products Count', 'designr' ),
		     'type'    => Controls_Manager::NUMBER,
		     'default' => 4,
		     'min'     => 1,
		     'max'     => 100,
		     'step'    => 1,
		  ]
		);


		$this->add_control(
			'designr_product_grid_categories',
			[
				'label' => esc_html__( 'Product Categories', 'designr' ),
				'type' => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple' => true,
				'options' => designr_woo_get_categories(),
			]
		);
		$this->add_control(
			'designr_title_show',
			[
				'label' => esc_html__( 'Show Title?', 'designr' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
				$this->add_control(
			'designr_price_show',
			[
				'label' => esc_html__( 'Show Price?', 'designr' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
			$this->add_control(
			'designr_old_price_show',
			[
				'label' => esc_html__( 'Show Old Price?', 'designr' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
				$this->add_control(
			'designr_button_show',
			[
				'label' => esc_html__( 'Show Button?', 'designr' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'designr_product_grid_rating',
			[
				'label' => esc_html__( 'Show Product Rating?', 'designr' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'ulproductsli_padding',
			[
				'label' => __( 'Margin Around Each Item', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} div.designr-product-grid ul.products > li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'designr_product_grid_styles',
			[
				'label' => esc_html__( 'Product Box Style', 'designr' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'designr_product_grid_background_color',
			[
				'label' => esc_html__( 'Content Background Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'designr_peoduct_grid_border',
				'selector' => '{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product',
			]
		);
		
		$this->add_control(
			'designr_peoduct_grid_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
				],
			]
		);
				
		
		$this->end_controls_section();


		$this->start_controls_section(
			'designr_section_product_grid_typography',
			[
				'label' => esc_html__( 'Title Style', 'designr' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);

		$this->add_control(
			'designr_product_grid_product_title_heading',
			[
				'label' => __( 'Product Title', 'designr' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'designr_product_grid_product_title_color',
			[
				'label' => esc_html__( 'Product Title Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#272727',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product .woocommerce-loop-product__title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'content_align2',
			[
				'label' => __( 'Alignment', 'designr' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'designr' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'designr' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'designr' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} div.designr-product-grid .woocommerce-loop-product__title' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
             'name' => 'designr_product_grid_product_title_typography',
				'selector' => '{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product .woocommerce-loop-product__title',
			]
		);
$this->end_controls_section();
$this->start_controls_section(
			'designr_section_product_grid_typography2',
			[
				'label' => esc_html__( 'Price Style', 'designr' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'designr_product_grid_product_price_heading',
			[
				'label' => __( 'Product Price', 'designr' ),
				'type' => Controls_Manager::HEADING,
			]
		);


		$this->add_control(
			'designr_product_grid_product_price_color',
			[
				'label' => esc_html__( 'Product Price Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#272727',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product .price' => 'color: {{VALUE}};',
				],
			]
		);
				$this->add_responsive_control(
			'content_align3',
			[
				'label' => __( 'Alignment', 'designr' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'designr' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'designr' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'designr' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} div.designr-product-grid span.price' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
             'name' => 'designr_product_grid_product_price_typography',
				'selector' => '{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product .price, {{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product .price ins span',
			]
		);
$this->end_controls_section();
$this->start_controls_section(
			'designr_section_product_grid_typography3',
			[
				'label' => esc_html__( 'Rating Stars Style', 'designr' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'designr_product_grid_product_rating_heading',
			[
				'label' => __( 'Star Rating', 'designr' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'designr_product_grid_product_rating_color',
			[
				'label' => esc_html__( 'Rating Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#f2b01e',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce .star-rating::before' => 'color: {{VALUE}};',
					'{{WRAPPER}} .designr-product-grid .woocommerce .star-rating span::before' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
             'name' => 'designr_product_grid_product_rating_typography',
				'selector' => '{{WRAPPER}} .designr-product-grid .woocommerce ul.products li.product .star-rating',
			]
		);
$this->end_controls_section();
$this->start_controls_section(
			'designr_section_product_grid_typography4',
			[
				'label' => esc_html__( 'Sale Badge Style', 'designr' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);
		$this->add_control(
			'designr_product_grid_sale_badge_heading',
			[
				'label' => __( 'Sale Badge', 'designr' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'designr_product_grid_sale_badge_color',
			[
				'label' => esc_html__( 'Sale Badge Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid:not(.designr-product-no-style) .onsale' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'designr_product_grid_sale_badge_background',
			[
				'label' => esc_html__( 'Sale Badge Background', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ff2a13',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid:not(.designr-product-no-style) .onsale' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
             'name' => 'designr_product_grid_sale_badge_typography',
				'selector' => '{{WRAPPER}} .designr-product-grid:not(.designr-product-no-style) .onsale',
			]
		);


		$this->end_controls_section();

		
		$this->start_controls_section(
			'designr_section_product_grid_add_to_cart_styles',
			[
				'label' => esc_html__( 'Button Style', 'designr' ),
				'tab' => Controls_Manager::TAB_STYLE
			]
		);


		$this->start_controls_tabs( 'designr_product_grid_add_to_cart_style_tabs' );

		$this->start_controls_tab( 'normal', [ 'label' => esc_html__( 'Normal', 'designr' ) ] );

		$this->add_control(
			'designr_product_grid_add_to_cart_color',
			[
				'label' => esc_html__( 'Button Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#333',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'border_radius_woo',
			[
				'label' => __( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} div.designr-product-grid ul.products a.button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);		
		$this->add_control(
			'button_padding',
			[
				'label' => __( 'Padding', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} div.designr-product-grid a.add_to_cart_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'designr_product_grid_add_to_cart_background',
			[
				'label' => esc_html__( 'Button Background Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button' => 'background-color: {{VALUE}};',
				],
			]
		);
				$this->add_responsive_control(
			'content_align5',
			[
				'label' => __( 'Alignment', 'designr' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'designr' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'designr' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'designr' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} div.designr-product-grid ul.products > li' => 'text-align: {{VALUE}};',
				],
			]
		);	
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'designr_product_grid_add_to_cart_border',
				'selector' => '{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
             'name' => 'designr_product_grid_add_to_cart_typography',
				'selector' => '{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'designr_product_grid_add_to_cart_hover_styles', [ 'label' => esc_html__( 'Hover', 'designr' ) ] );

		$this->add_control(
			'designr_product_grid_add_to_cart_hover_color',
			[
				'label' => esc_html__( 'Button Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#333',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button:hover' => 'color: {{VALUE}};',
				],
			]
		);	
		$this->add_control(
			'designr_product_grid_add_to_cart_hover_background',
			[
				'label' => esc_html__( 'Button Background Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#f9f9f9',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
				
		$this->add_control(
			'designr_product_grid_add_to_cart_hover_border_color',
			[
				'label' => esc_html__( 'Border Color', 'designr' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .designr-product-grid .woocommerce li.product .button.add_to_cart_button:hover' => 'border-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_tab();
		
		$this->end_controls_tabs();


		$this->end_controls_section();
		
		
	}


	protected function render( ) {
		
			
		$settings = $this->get_settings();
			$product_grid_classes = "";
		$product_count = $this->get_settings( 'designr_product_grid_products_count' );
		$columns = $this->get_settings( 'designr_product_grid_column' );
		$show_rating = ( ($settings['designr_product_grid_rating'] == 'yes') ? "show_rating" : "hide_rating" );
		$product_grid_classes .= $show_rating;
        if(!$settings['designr_title_show'] == 'yes'){ 
		$product_grid_classes .= " designr-hide-titles";
		}
		if(!$settings['designr_price_show'] == 'yes'){ 
		$product_grid_classes .= " designr-hide-prices";
		}
		if(!$settings['designr_button_show'] == 'yes'){ 
		$product_grid_classes .= " designr-hide-buttons";
		}
		if(!$settings['designr_old_price_show'] == 'yes'){ 
		$product_grid_classes .= " designr-hide-old-price";
		}
		$get_product_categories = $settings['designr_product_grid_categories']; // get custom field value
		if($get_product_categories >= 1 ) { 
			$cats_ids = implode(', ', $get_product_categories); 
		} else {
			$cats_ids = '';
		}

	?>



<div id="designr-product-grid-<?php echo esc_attr($this->get_id()); ?>" class="designr-product-carousel designr-product-grid <?php echo $product_grid_classes; ?>">

	<?php 
	if ( ($settings['designr_product_grid_product_filter']) == 'recent-products' ) : ?>

		<?php echo do_shortcode("[recent_products per_page=\"$product_count\" columns=\"$columns\" category=\"$cats_ids\"]"); ?>

	<?php elseif ( ($settings['designr_product_grid_product_filter']) == 'featured-products' ) : ?>

		<?php echo do_shortcode("[featured_products per_page=\"$product_count\" columns=\"$columns\" category=\"$cats_ids\"]") ?>

	<?php elseif ( ($settings['designr_product_grid_product_filter']) == 'best-selling-products' ) : ?>

		<?php echo do_shortcode("[best_selling_products per_page=\"$product_count\" columns=\"$columns\" category=\"$cats_ids\"]") ?>

	<?php elseif ( ($settings['designr_product_grid_product_filter']) == 'sale-products' ) : ?>

		<?php echo do_shortcode("[sale_products per_page=\"$product_count\" columns=\"$columns\" category=\"$cats_ids\"]") ?>

	<?php else: ?>

		<?php echo do_shortcode("[top_rated_products per_page=\"$product_count\" columns=\"$columns\" category=\"$cats_ids\"]") ?>

	<?php endif; ?>

    <div class="clearfix"></div>
</div>

	
	<?php
	
	}
}