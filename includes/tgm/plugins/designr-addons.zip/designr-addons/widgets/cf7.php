<?php
namespace HelloWorld\Widgets;
use Elementor\Element_Base;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Controls_Manager;
use ElementorWPFormStyler\Modules\Stylers\Skins;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Designr_CF7 extends Widget_Base {
	
	public function designr_getforms() {
    $cf7_array = array();

        $args = array(
            'post_type' => 'wpcf7_contact_form',
        );
        
        $wpcf7 = get_posts($args);

        foreach( $wpcf7 as $post ) { setup_postdata( $post );
            $cf7_array[$post->ID] = $post->post_title;
        } 

        return $cf7_array;
     wp_reset_postdata();
    }

	public function get_name() {
		return 'contact-form-7';
	}

	public function get_title() {
		return __( 'Contact Form 7', 'designr' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return [ 'designr-elements' ];
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'contact_form',
			[
				'label' => __( 'Form Details', 'designr' ),
			]
		);

		$this->add_control(
			'select_form',
			[
				'label' => __( 'Contact Form 7', 'designr' ),
				'type' => Controls_Manager::SELECT,
				'default' => [],
				'options' => Designr_CF7::designr_getforms(),
				'description' => __( 'Choose form you already created in backend.', 'designr' ),
			]
		);

		$this->add_responsive_control(
			'content_align',
			[
				'label' => __( 'Alignment', 'designr' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'designr' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'designr' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'designr' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .wpcf7-form > p' => 'text-align: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_section();
		
			$this->start_controls_section(
			'label_options',
			[
				'label' => __( 'Form Labels', 'designr' ),
			]
		);		
		
		$this->add_control(
			'label_padding',
			[
				'label' => __( 'Padding', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography1',
				'selector' => '{{WRAPPER}} .wpcf7 p label',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);
		$this->add_control(
			'label_color',
			[
				'label' => __( 'Label Color', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#6b7c93',
				'selectors' => [
					'{{WRAPPER}} .wpcf7 p label' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'fields_options',
			[
				'label' => __( 'Form Fields', 'designr' ),
			]
		);
		$this->add_control(
			'fields_padding',
			[
				'label' => __( 'Padding', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input:not([type=submit])' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'fields_margin',
			[
				'label' => __( 'Margin', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input:not([type=submit]), {{WRAPPER}} .wpcf7 textarea' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);		
		$this->add_responsive_control(
			'fields_width',
			[
				'label'          => __( 'Width', 'designr' ),
				'type'           => Controls_Manager::SLIDER,
				'range'          => [
					'%'  => [
						'min' => 20,
						'max' => 100,
					],
					'px' => [
						'min' => 30,
						'max' => 600,
					],
				],
				'default'        => [
					'size' => 100,
					'unit' => '%',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default' => [
					'size' => 100,
					'unit' => '%',
				],
				'size_units'     => [ '%', 'px' ],
				'selectors'      => [
					'{{WRAPPER}} .wpcf7 input:not([type=submit])' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'field_border',
				'label' => __( 'Border', 'designr' ),
				'default' => '1px',
				'selector' => '{{WRAPPER}} .wpcf7 input:not([type=submit]), {{WRAPPER}} .wpcf7 textarea',
			]
		);

		$this->add_control(
			'field_radius',
			[
				'label' => __( 'Border Radius', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input:not([type=submit]), {{WRAPPER}} .wpcf7 textarea' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography2',
				'selector' => '{{WRAPPER}} .wpcf7 input:not([type=submit]),  {{WRAPPER}} .wpcf7 textarea',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);
       $this->add_control(
			'input_color',
			[
				'label' => __( 'Color', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#6b7c93',
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input:not([type=submit]),  {{WRAPPER}} .wpcf7 textarea' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'inputbg2',
			[
				'label' => __( 'Background Color', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#FFFFFF',
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input:not([type=submit]),  {{WRAPPER}} .wpcf7 textarea' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'inputbg3',
			[
				'label' => __( 'Background Color On Focus', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#FFFFFF',
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input:focus:not([type=submit]),  {{WRAPPER}} .wpcf7 textarea:focus' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'textarea_options',
			[
				'label' => __( 'Form Textarea', 'designr' ),
			]
		);
		
		$this->add_responsive_control(
			'textarea_width',
			[
				'label'          => __( 'Width', 'designr' ),
				'type'           => Controls_Manager::SLIDER,
				'range'          => [
					'%'  => [
						'min' => 10,
						'max' => 100,
					],
					'px' => [
						'min' => 10,
						'max' => 600,
					],
				],
				'default'        => [
					'size' => 100,
					'unit' => '%',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default' => [
					'size' => 100,
					'unit' => '%',
				],
				'size_units'     => [ '%', 'px' ],
				'selectors'      => [
					'{{WRAPPER}} .wpcf7 textarea' => 'width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'textarea_padding',
			[
				'label' => __( 'Padding', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'textarea_height',
			[
				'label'          => __( 'Height', 'designr' ),
				'type'           => Controls_Manager::SLIDER,
				'range'          => [
					'%'  => [
						'min' => 10,
						'max' => 100,
					],
					'px' => [
						'min' => 10,
						'max' => 600,
					],
				],
				'default'        => [
					'size' => 200,
					'unit' => 'px',
				],
				'tablet_default' => [
					'size' => '',
					'unit' => '%',
				],
				'mobile_default' => [
					'size' => 200,
					'unit' => 'px',
				],
				'size_units'     => [ '%', 'px' ],
				'selectors'      => [
					'{{WRAPPER}} .wpcf7 textarea' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'button_options',
			[
				'label' => __( 'Form Button', 'designr' ),
			]
		);		
		
		$this->add_control(
			'button_padding',
			[
				'label' => __( 'Padding', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input[type="submit"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'button_marg',
			[
				'label' => __( 'Margin', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input[type="submit"]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'button_border',
				'label' => __( 'Border', 'designr' ),
				'default' => '1px',
				'selector' => '{{WRAPPER}} .wpcf7 input[type="submit"]',
			]
		);

		$this->add_control(
			'button_radius',
			[
				'label' => __( 'Radius', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wpcf7 input[type="submit"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography4',
				'selector' => '{{WRAPPER}} .wpcf7 input[type="submit"]',
				'scheme' => Scheme_Typography::TYPOGRAPHY_3,
			]
		);
		$this->add_control(
			'button_syles3',
			[
				'label' => __( 'Button Text Color', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} input[type="submit"]' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'button_syles4',
			[
				'label' => __( 'Button Text Color Hover', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#333',
				'selectors' => [
					'{{WRAPPER}} input[type="submit"]:hover' => 'color: {{VALUE}};',
				],
			]
		);		
		$this->add_control(
			'button_syles1',
			[
				'label' => __( 'Background Color', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#333333',
				'selectors' => [
					'{{WRAPPER}} input[type="submit"]' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'button_syles2',
			[
				'label' => __( 'Background Color Hover', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} input[type="submit"]:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'message_options',
			[
				'label' => __( 'Success/Error Message', 'designr' ),
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'res_border',
				'label' => __( 'Border', 'designr' ),
				'default' => '1px',
				'selector' => '{{WRAPPER}} div.wpcf7-response-output',
			]
		);

		$this->add_control(
			'res_radius',
			[
				'label' => __( 'Border Radius', 'designr' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} div.wpcf7-response-output' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'message_typography',
				'label' => __( 'Typography', 'designr' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} div.wpcf7-response-output',
			]
		);
		$this->add_control(
			'message_text',
			[
				'label' => __( 'Color', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#333333',
				'selectors' => [
					'{{WRAPPER}} div.wpcf7-response-output' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'message_bg',
			[
				'label' => __( 'Background', 'designr' ),
				'type' => Controls_Manager::COLOR,	
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} div.wpcf7-response-output' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings();
		
		$selected_form = $settings['select_form']; 

		echo do_shortcode('[contact-form-7 id="' . $selected_form . '"]');

	}

	protected function content_template() {}

	public function render_plain_content( $settings = [] ) {}

}