<?php
namespace HelloWorld\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Utils;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Designr_Portfolio extends Widget_Base {

	public function get_name() {
		return 'Portfolio';
	}

	public function get_title() {
		return __( 'Portfolio', 'elementor' );
	}

	public function get_icon() {
		return 'fa fa-table';
	}
	public function get_script_depends() {
		return [ 'jquery-filterizr' ];
	}
	public function get_categories() {
		return [ 'designr-elements' ];
	}

	protected function _register_controls() {
		// Content
		// Name
		$this->start_controls_section(
			'section_style_Portfolio_name',
			[
				'label' => __( 'Navigation', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'name_text_color',
			[
				'label' => __( 'Text Color', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} ul.pnav li a' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'name_text_color2',
			[
				'label' => __( 'Text Color Active/Hover', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} ul.pnav li a.active, {{WRAPPER}} ul.pnav li a:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'pnav_alignment',
			[
				'label' => __( 'Nav Alignment', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'default' => 'center',
				'options' => [
					'left'    => [
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'fa fa-align-center',
					]
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'label' => __( 'Typography', 'elementor' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ul.pnav li a',
			]
		);

		$this->end_controls_section();
		// dots
		$this->start_controls_section(
			'section_imghover',
			[
				'label' => __( 'Image Settings', 'elementor' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'name_text_color3',
			[
				'label' => __( 'Image Hover Background', 'elementor' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Scheme_Color::get_type(),
					'value' => Scheme_Color::COLOR_1,
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .box-content' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'image_border_radius2',
			[
				'label' => __( 'Border Radius', 'elementor' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} div.filtr-item > div > img, {{WRAPPER}} .box-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				]
			]
		);
        
		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		$this->add_render_attribute( 'wrapper', 'class', 'designr-Portfolio-wrapper' );

		if ( $settings['pnav_alignment'] ) {
			$this->add_render_attribute( 'wrapper', 'class', 'pnav-' . $settings['pnav_alignment'] );
		}
		?>
		<div <?php echo $this->get_render_attribute_string( 'wrapper' ); ?>>
        <div class="Portfolio-mainwrap">
		<?php
		 $terms = get_terms("portfolio-categories");
    $count = count($terms);
    echo '<ul class="pnav">';
    echo '<li><a href="javascript:;" class="active" data-filter="all">All Works</a></li>';
        if ( $count > 0 )
        {   
            foreach ( $terms as $term ) {
                $termname = strtolower($term->name);
                $termname = str_replace(' ', '-', $termname);
                echo '<li><a href="javascript:;" data-filter="'.$term->term_id.'">'.$term->name.'</a></li>';
            }
        }
    echo "</ul>";
		?>
		<!-- Portfolio Items -->
        <div id="portfolio" class="filtr-container">
        <div class="container">
		<div class="center-items">
		<?php	
$args = array( 'post_type'=>'portfolios', 'showposts'=>'30');
$allposts = get_posts( $args );
foreach ( $allposts as $post ){ 
  setup_postdata( $post );
  $term_list = wp_get_post_terms($post->ID, 'portfolio-categories', array("fields" => "ids"));
  $finallist = implode(", ",$term_list);
  ?>
         <div class="filtr-item" data-category="<?php echo $finallist;?>">
                            <div> 
							<?php echo get_the_post_thumbnail($post->ID, "designr_portfolio-fixed-width");?>
                                <div class="box-content">
								<h4 class="white"><?php echo get_the_title($post->ID);?></h4>
                                    <p>
                                        <a href="<?php echo get_the_post_thumbnail_url($post->ID, "full");?>" data-featherlight="image"><i class="fa fa-expand"></i></a>
                                        <a href="<?php echo get_permalink($post->ID);?>"><i class="fa fa-link"></i></a>
                                    </p>
                                </div>
                            </div>
        </div>
	<?php  }  wp_reset_postdata();?>
	</div></div></div>
			</div>
		</div>
	<?php
	$mainjs = 'jQuery("ul.pnav a").click(function(){
	jQuery("ul.pnav a").removeClass("active");
	jQuery(this).addClass("active");
});
		var filterizd = jQuery(".filtr-container > .container > .center-items").filterizr({
"layout": "sameWidth",			
    "delay": 25,
	"delayMode": "progressive",
    "filterOutCss": {
        "opacity": 0,
        "transform": "translate(0px, -35px)"
    },
    "filterInCss": {
        "opacity": 1,
        "transform": "translate(0px, 0px)"
    }
});';
	wp_add_inline_script( 'jquery-filterizr', $mainjs);
	}

	protected function _content_template() {
	}
}